"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface BlackjackTableProps {
  credits: number
  setCredits: (credits: number) => void
  playerRank: string
  onGameEnd: (won: boolean, lpChange: number) => void
}

interface PlayingCard {
  suit: string
  value: string
  numValue: number
}

export default function BlackjackTable({ credits, setCredits, playerRank, onGameEnd }: BlackjackTableProps) {
  const [playerHand, setPlayerHand] = useState<PlayingCard[]>([])
  const [dealerHand, setDealerHand] = useState<PlayingCard[]>([])
  const [gameState, setGameState] = useState<"betting" | "playing" | "dealer" | "finished">("betting")
  const [bet, setBet] = useState(10)
  const [message, setMessage] = useState("Placez votre mise")
  const [playerScore, setPlayerScore] = useState(0)
  const [dealerScore, setDealerScore] = useState(0)
  const [showDealerCard, setShowDealerCard] = useState(false)

  const suits = ["♠", "♥", "♦", "♣"]
  const values = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]

  const createDeck = (): PlayingCard[] => {
    const deck: PlayingCard[] = []
    suits.forEach((suit) => {
      values.forEach((value) => {
        let numValue = Number.parseInt(value)
        if (value === "A") numValue = 11
        if (["J", "Q", "K"].includes(value)) numValue = 10
        deck.push({ suit, value, numValue })
      })
    })
    return deck.sort(() => Math.random() - 0.5)
  }

  const calculateScore = (hand: PlayingCard[]): number => {
    let score = 0
    let aces = 0

    hand.forEach((card) => {
      if (card.value === "A") {
        aces++
        score += 11
      } else {
        score += card.numValue
      }
    })

    while (score > 21 && aces > 0) {
      score -= 10
      aces--
    }

    return score
  }

  const dealCard = (deck: PlayingCard[]): PlayingCard => {
    return deck.pop()!
  }

  const calculateLPChange = (won: boolean): number => {
    if (playerRank === "Bronze") {
      return won ? 5 : -5
    } else if (playerRank === "Silver") {
      return won ? 10 : -10
    } else if (playerRank === "Gold") {
      return won ? 15 : -15
    } else {
      return won ? 20 : -20
    }
  }

  const startGame = () => {
    if (bet > credits) {
      setMessage("Mise trop élevée!")
      return
    }

    const deck = createDeck()
    const newPlayerHand = [dealCard(deck), dealCard(deck)]
    const newDealerHand = [dealCard(deck), dealCard(deck)]

    setPlayerHand(newPlayerHand)
    setDealerHand(newDealerHand)
    setPlayerScore(calculateScore(newPlayerHand))
    setDealerScore(calculateScore([newDealerHand[0]]))
    setGameState("playing")
    setShowDealerCard(false)
    setMessage("Voulez-vous une carte?")
    setCredits(credits - bet)
  }

  const hit = () => {
    const deck = createDeck()
    const newCard = dealCard(deck)
    const newHand = [...playerHand, newCard]
    setPlayerHand(newHand)

    const newScore = calculateScore(newHand)
    setPlayerScore(newScore)

    if (newScore > 21) {
      setGameState("finished")
      setMessage("Bust! Vous avez perdu.")
      onGameEnd(false, calculateLPChange(false))
    }
  }

  const stand = () => {
    setGameState("dealer")
    setShowDealerCard(true)

    const currentDealerHand = [...dealerHand]
    let currentDealerScore = calculateScore(currentDealerHand)

    const deck = createDeck()
    while (currentDealerScore < 17) {
      const newCard = dealCard(deck)
      currentDealerHand.push(newCard)
      currentDealerScore = calculateScore(currentDealerHand)
    }

    setDealerHand(currentDealerHand)
    setDealerScore(currentDealerScore)

    setTimeout(() => {
      if (currentDealerScore > 21) {
        setMessage("Le croupier bust! Vous gagnez!")
        setCredits(credits + bet * 2)
        onGameEnd(true, calculateLPChange(true))
      } else if (currentDealerScore > playerScore) {
        setMessage("Le croupier gagne!")
        onGameEnd(false, calculateLPChange(false))
      } else if (playerScore > currentDealerScore) {
        setMessage("Vous gagnez!")
        setCredits(credits + bet * 2)
        onGameEnd(true, calculateLPChange(true))
      } else {
        setMessage("Égalité!")
        setCredits(credits + bet)
        onGameEnd(false, 0) // No LP change on tie
      }
      setGameState("finished")
    }, 1000)
  }

  const newGame = () => {
    setPlayerHand([])
    setDealerHand([])
    setGameState("betting")
    setMessage("Placez votre mise")
    setPlayerScore(0)
    setDealerScore(0)
    setShowDealerCard(false)
  }

  const CardComponent = ({ card, hidden = false }: { card: PlayingCard; hidden?: boolean }) => (
    <div
      className={`w-16 h-24 rounded-lg border-2 flex flex-col items-center justify-center text-lg font-bold ${
        hidden ? "bg-blue-900 border-blue-700" : "bg-white border-gray-300"
      } ${card.suit === "♥" || card.suit === "♦" ? "text-red-500" : "text-black"}`}
    >
      {hidden ? (
        "?"
      ) : (
        <>
          <div>{card.value}</div>
          <div>{card.suit}</div>
        </>
      )}
    </div>
  )

  return (
    <div className="text-white space-y-6">
      {/* Game Info */}
      <div className="flex justify-between items-center">
        <div className="flex space-x-4">
          <Badge variant="outline" className="border-yellow-400 text-yellow-400">
            Crédits: {credits}
          </Badge>
          <Badge variant="outline" className="border-green-400 text-green-400">
            Mise: {bet}
          </Badge>
        </div>
        <div className="text-xl font-bold">{message}</div>
      </div>

      {/* Dealer Hand */}
      <div className="space-y-2">
        <h3 className="text-lg font-bold">Croupier ({showDealerCard ? dealerScore : "?"})</h3>
        <div className="flex space-x-2">
          {dealerHand.map((card, index) => (
            <CardComponent key={index} card={card} hidden={index === 1 && !showDealerCard} />
          ))}
        </div>
      </div>

      {/* Player Hand */}
      <div className="space-y-2">
        <h3 className="text-lg font-bold">Votre main ({playerScore})</h3>
        <div className="flex space-x-2">
          {playerHand.map((card, index) => (
            <CardComponent key={index} card={card} />
          ))}
        </div>
      </div>

      {/* Controls */}
      <div className="space-y-4">
        {gameState === "betting" && (
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <span>Mise:</span>
              <div className="flex space-x-2">
                {[10, 25, 50, 100].map((amount) => (
                  <Button
                    key={amount}
                    variant={bet === amount ? "default" : "outline"}
                    size="sm"
                    onClick={() => setBet(amount)}
                    disabled={amount > credits}
                    className={bet === amount ? "bg-green-600 hover:bg-green-700" : ""}
                  >
                    {amount}
                  </Button>
                ))}
              </div>
            </div>
            <Button onClick={startGame} className="bg-green-600 hover:bg-green-700">
              Distribuer
            </Button>
          </div>
        )}

        {gameState === "playing" && (
          <div className="flex space-x-4">
            <Button onClick={hit} className="bg-blue-600 hover:bg-blue-700">
              Carte
            </Button>
            <Button onClick={stand} className="bg-red-600 hover:bg-red-700">
              Rester
            </Button>
          </div>
        )}

        {gameState === "finished" && (
          <Button onClick={newGame} className="bg-yellow-600 hover:bg-yellow-700">
            Nouvelle partie
          </Button>
        )}
      </div>
    </div>
  )
}
