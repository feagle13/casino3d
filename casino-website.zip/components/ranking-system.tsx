"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Trophy, TrendingUp, Star, Crown, Award } from "lucide-react"

interface PlayerStats {
  blackjack: { rank: string; lp: number; wins: number; losses: number }
  roulette: { rank: string; lp: number; wins: number; losses: number }
  slots: { rank: string; lp: number; wins: number; losses: number }
  poker: { rank: string; lp: number; wins: number; losses: number }
}

interface RankingSystemProps {
  playerStats: PlayerStats
  onClose: () => void
}

export default function RankingSystem({ playerStats, onClose }: RankingSystemProps) {
  const [selectedGame, setSelectedGame] = useState<keyof PlayerStats>("poker")

  const ranks = [
    { name: "Bronze III", lp: 0, color: "text-orange-400", icon: "🥉" },
    { name: "Bronze II", lp: 100, color: "text-orange-400", icon: "🥉" },
    { name: "Bronze I", lp: 200, color: "text-orange-400", icon: "🥉" },
    { name: "Silver III", lp: 300, color: "text-gray-300", icon: "🥈" },
    { name: "Silver II", lp: 400, color: "text-gray-300", icon: "🥈" },
    { name: "Silver I", lp: 500, color: "text-gray-300", icon: "🥈" },
    { name: "Gold III", lp: 600, color: "text-yellow-400", icon: "🥇" },
    { name: "Gold II", lp: 700, color: "text-yellow-400", icon: "🥇" },
    { name: "Gold I", lp: 800, color: "text-yellow-400", icon: "🥇" },
    { name: "Platinum III", lp: 900, color: "text-cyan-400", icon: "💎" },
    { name: "Platinum II", lp: 1000, color: "text-cyan-400", icon: "💎" },
    { name: "Platinum I", lp: 1100, color: "text-cyan-400", icon: "💎" },
    { name: "Diamond III", lp: 1200, color: "text-blue-400", icon: "💠" },
    { name: "Diamond II", lp: 1300, color: "text-blue-400", icon: "💠" },
    { name: "Diamond I", lp: 1400, color: "text-blue-400", icon: "💠" },
    { name: "Master", lp: 1500, color: "text-purple-400", icon: "👑" },
    { name: "Grandmaster", lp: 1800, color: "text-red-400", icon: "🔥" },
  ]

  const leaderboard = [
    { name: "PokerPro2024", rank: "Grandmaster", lp: 2156, game: "poker" },
    { name: "BlackjackKing", rank: "Master", lp: 1789, game: "blackjack" },
    { name: "RouletteQueen", rank: "Diamond I", lp: 1456, game: "roulette" },
    { name: "SlotMaster", rank: "Diamond II", lp: 1334, game: "slots" },
    { name: "CardShark", rank: "Diamond III", lp: 1267, game: "poker" },
    { name: "LuckyPlayer", rank: "Platinum I", lp: 1156, game: "roulette" },
    { name: "Vous", rank: playerStats[selectedGame].rank, lp: playerStats[selectedGame].lp, game: selectedGame },
  ].sort((a, b) => b.lp - a.lp)

  const getRankColor = (rank: string) => {
    if (rank.includes("Bronze")) return "text-orange-400"
    if (rank.includes("Silver")) return "text-gray-300"
    if (rank.includes("Gold")) return "text-yellow-400"
    if (rank.includes("Platinum")) return "text-cyan-400"
    if (rank.includes("Diamond")) return "text-blue-400"
    if (rank.includes("Master")) return "text-purple-400"
    if (rank.includes("Grandmaster")) return "text-red-400"
    return "text-white"
  }

  const getRankIcon = (rank: string) => {
    if (rank.includes("Bronze")) return "🥉"
    if (rank.includes("Silver")) return "🥈"
    if (rank.includes("Gold")) return "🥇"
    if (rank.includes("Platinum")) return "💎"
    if (rank.includes("Diamond")) return "💠"
    if (rank.includes("Master")) return "👑"
    if (rank.includes("Grandmaster")) return "🔥"
    return "🎯"
  }

  const getNextRank = (currentRank: string, currentLp: number) => {
    const currentRankIndex = ranks.findIndex((r) => r.name === currentRank)
    if (currentRankIndex < ranks.length - 1) {
      const nextRank = ranks[currentRankIndex + 1]
      const lpNeeded = nextRank.lp - currentLp
      return { name: nextRank.name, lpNeeded }
    }
    return null
  }

  const getWinRate = (wins: number, losses: number) => {
    const total = wins + losses
    return total > 0 ? Math.round((wins / total) * 100) : 0
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white flex items-center">
          <Trophy className="w-8 h-8 mr-3 text-yellow-400" />
          Système de Ranking
        </h2>
        <Button onClick={onClose} variant="outline" className="border-slate-600 text-slate-300">
          Fermer
        </Button>
      </div>

      {/* Game Selection */}
      <div className="flex justify-center space-x-4">
        {Object.keys(playerStats).map((game) => (
          <Button
            key={game}
            variant={selectedGame === game ? "default" : "outline"}
            onClick={() => setSelectedGame(game as keyof PlayerStats)}
            className={selectedGame === game ? "bg-blue-600 hover:bg-blue-700" : "border-slate-600"}
          >
            {game.charAt(0).toUpperCase() + game.slice(1)}
          </Button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Player Stats */}
        <div className="lg:col-span-2 space-y-6">
          {/* Current Rank */}
          <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              <Star className="w-5 h-5 mr-2" />
              Votre Rang - {selectedGame.charAt(0).toUpperCase() + selectedGame.slice(1)}
            </h3>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="text-6xl">{getRankIcon(playerStats[selectedGame].rank)}</div>
                <div>
                  <div className={`text-2xl font-bold ${getRankColor(playerStats[selectedGame].rank)}`}>
                    {playerStats[selectedGame].rank}
                  </div>
                  <div className="text-lg text-slate-300">{playerStats[selectedGame].lp} LP</div>
                  <div className="text-sm text-slate-400">
                    Taux de victoire: {getWinRate(playerStats[selectedGame].wins, playerStats[selectedGame].losses)}%
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-slate-400">Victoires</div>
                <div className="text-xl font-bold text-green-400">{playerStats[selectedGame].wins}</div>
                <div className="text-sm text-slate-400">Défaites</div>
                <div className="text-xl font-bold text-red-400">{playerStats[selectedGame].losses}</div>
              </div>
            </div>

            {/* Progress to next rank */}
            {(() => {
              const nextRank = getNextRank(playerStats[selectedGame].rank, playerStats[selectedGame].lp)
              if (nextRank) {
                const progress = Math.max(0, 100 - (nextRank.lpNeeded / 100) * 100)
                return (
                  <div className="mt-4">
                    <div className="flex justify-between text-sm text-slate-400 mb-2">
                      <span>Progression vers {nextRank.name}</span>
                      <span>{nextRank.lpNeeded} LP restants</span>
                    </div>
                    <div className="w-full bg-slate-700 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${progress}%` }}
                      ></div>
                    </div>
                  </div>
                )
              }
              return (
                <div className="mt-4 text-center">
                  <Badge className="bg-red-600">Rang Maximum Atteint!</Badge>
                </div>
              )
            })()}
          </div>

          {/* Rank Ladder */}
          <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2" />
              Échelle des Rangs
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {ranks.map((rank, index) => (
                <div
                  key={rank.name}
                  className={`p-3 rounded-lg border transition-all ${
                    rank.name === playerStats[selectedGame].rank
                      ? "border-yellow-400 bg-yellow-400/10"
                      : "border-slate-600 bg-slate-700/50"
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-lg">{rank.icon}</span>
                    <div>
                      <div className={`font-bold ${rank.color}`}>{rank.name}</div>
                      <div className="text-xs text-slate-400">{rank.lp}+ LP</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Leaderboard */}
        <div className="space-y-6">
          <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              <Crown className="w-5 h-5 mr-2 text-yellow-400" />
              Classement Global
            </h3>
            <div className="space-y-3">
              {leaderboard.map((player, index) => (
                <div
                  key={player.name}
                  className={`flex items-center justify-between p-3 rounded-lg ${
                    player.name === "Vous" ? "bg-blue-600/20 border border-blue-400" : "bg-slate-700/50"
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                        index === 0
                          ? "bg-yellow-400 text-black"
                          : index === 1
                            ? "bg-gray-300 text-black"
                            : index === 2
                              ? "bg-orange-400 text-black"
                              : "bg-slate-600 text-white"
                      }`}
                    >
                      {index + 1}
                    </div>
                    <div>
                      <div className="font-bold text-white">{player.name}</div>
                      <div className="text-xs text-slate-400">{player.game}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`font-bold ${getRankColor(player.rank)}`}>{player.rank}</div>
                    <div className="text-sm text-slate-400">{player.lp} LP</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Season Info */}
          <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              <Award className="w-5 h-5 mr-2 text-purple-400" />
              Saison Actuelle
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-slate-300">Saison</span>
                <span className="text-white font-bold">Saison 1</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-300">Temps restant</span>
                <span className="text-white font-bold">45 jours</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-300">Récompenses</span>
                <Badge className="bg-purple-600">Disponibles</Badge>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
