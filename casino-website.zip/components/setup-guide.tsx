"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Copy, Check, Terminal, Key, Globe } from "lucide-react"

export default function SetupGuide() {
  const [copiedSecret, setCopiedSecret] = useState(false)
  const [copiedEnv, setCopiedEnv] = useState(false)

  const generateSecret = () => {
    // Simulation de la génération (en vrai, utiliser openssl)
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
    let result = ""
    for (let i = 0; i < 44; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return result
  }

  const copyToClipboard = async (text: string, type: "secret" | "env") => {
    try {
      await navigator.clipboard.writeText(text)
      if (type === "secret") {
        setCopiedSecret(true)
        setTimeout(() => setCopiedSecret(false), 2000)
      } else {
        setCopiedEnv(true)
        setTimeout(() => setCopiedEnv(false), 2000)
      }
    } catch (err) {
      console.error("Erreur de copie:", err)
    }
  }

  const secretKey = generateSecret()
  const envContent = `# NextAuth.js Configuration
NEXTAUTH_SECRET=${secretKey}
NEXTAUTH_URL=http://localhost:3000

# Google OAuth (optionnel)
# GOOGLE_CLIENT_ID=your-google-client-id
# GOOGLE_CLIENT_SECRET=your-google-client-secret`

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
              <span className="text-black font-bold text-2xl">D</span>
            </div>
            <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
              DPC'asino
            </h1>
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Configuration Initiale</h2>
          <p className="text-slate-300">Configurez votre environnement de développement</p>
        </div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Step 1 */}
          <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                1
              </div>
              <h3 className="text-lg font-bold text-white">Générer la clé</h3>
            </div>
            <p className="text-slate-300 mb-4">Générez une clé secrète sécurisée pour NextAuth.js</p>
            <div className="bg-slate-900 rounded-lg p-3 mb-4">
              <code className="text-green-400 text-sm">openssl rand -base64 32</code>
            </div>
            <Badge className="bg-green-600">
              <Terminal className="w-4 h-4 mr-1" />
              Commande Terminal
            </Badge>
          </div>

          {/* Step 2 */}
          <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-yellow-600 rounded-full flex items-center justify-center text-white font-bold">
                2
              </div>
              <h3 className="text-lg font-bold text-white">Créer .env.local</h3>
            </div>
            <p className="text-slate-300 mb-4">Créez le fichier de configuration à la racine du projet</p>
            <div className="bg-slate-900 rounded-lg p-3 mb-4">
              <code className="text-blue-400 text-sm">.env.local</code>
            </div>
            <Badge className="bg-yellow-600">
              <Key className="w-4 h-4 mr-1" />
              Variables d'environnement
            </Badge>
          </div>

          {/* Step 3 */}
          <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center text-white font-bold">
                3
              </div>
              <h3 className="text-lg font-bold text-white">Démarrer</h3>
            </div>
            <p className="text-slate-300 mb-4">Lancez le serveur de développement</p>
            <div className="bg-slate-900 rounded-lg p-3 mb-4">
              <code className="text-green-400 text-sm">npm run dev</code>
            </div>
            <Badge className="bg-green-600">
              <Globe className="w-4 h-4 mr-1" />
              Serveur Local
            </Badge>
          </div>
        </div>

        {/* Generated Secret */}
        <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center">
            <Key className="w-5 h-5 mr-2 text-yellow-400" />
            Clé Secrète Générée
          </h3>
          <div className="bg-slate-900 rounded-lg p-4 mb-4">
            <div className="flex justify-between items-center">
              <code className="text-green-400 text-sm break-all">{secretKey}</code>
              <Button
                size="sm"
                onClick={() => copyToClipboard(secretKey, "secret")}
                className="ml-4 bg-blue-600 hover:bg-blue-700"
              >
                {copiedSecret ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
          </div>
          <p className="text-slate-400 text-sm">⚠️ Gardez cette clé secrète et ne la partagez jamais publiquement</p>
        </div>

        {/* Complete .env.local */}
        <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-white flex items-center">
              <Terminal className="w-5 h-5 mr-2 text-blue-400" />
              Contenu du fichier .env.local
            </h3>
            <Button
              size="sm"
              onClick={() => copyToClipboard(envContent, "env")}
              className="bg-green-600 hover:bg-green-700"
            >
              {copiedEnv ? <Check className="w-4 h-4 mr-1" /> : <Copy className="w-4 h-4 mr-1" />}
              Copier tout
            </Button>
          </div>
          <div className="bg-slate-900 rounded-lg p-4 overflow-x-auto">
            <pre className="text-green-400 text-sm whitespace-pre-wrap">{envContent}</pre>
          </div>
        </div>

        {/* Demo Accounts */}
        <div className="bg-gradient-to-r from-purple-900/50 to-blue-900/50 rounded-xl p-6 border border-purple-500/30">
          <h3 className="text-xl font-bold text-white mb-4">Comptes de Démonstration</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-800/50 rounded-lg p-4">
              <h4 className="font-bold text-white mb-2">Utilisateur Demo</h4>
              <p className="text-sm text-slate-300">Email: demo@example.com</p>
              <p className="text-sm text-slate-300">Mot de passe: demo123</p>
            </div>
            <div className="bg-slate-800/50 rounded-lg p-4">
              <h4 className="font-bold text-white mb-2">Administrateur</h4>
              <p className="text-sm text-slate-300">Email: admin@dpcasino.com</p>
              <p className="text-sm text-slate-300">Mot de passe: admin123</p>
            </div>
            <div className="bg-slate-800/50 rounded-lg p-4">
              <h4 className="font-bold text-white mb-2">Joueur Test</h4>
              <p className="text-sm text-slate-300">Email: player@test.com</p>
              <p className="text-sm text-slate-300">Mot de passe: player123</p>
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-blue-900/20 rounded-xl p-6 border border-blue-500/30">
          <h3 className="text-lg font-bold text-white mb-4">Instructions Détaillées</h3>
          <div className="space-y-3 text-slate-300">
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold mt-0.5">
                1
              </div>
              <div>
                <p className="font-medium">Ouvrez un terminal dans le dossier du projet</p>
                <code className="text-blue-400 text-sm">cd votre-projet-casino</code>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold mt-0.5">
                2
              </div>
              <div>
                <p className="font-medium">Générez une clé secrète</p>
                <code className="text-blue-400 text-sm">openssl rand -base64 32</code>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold mt-0.5">
                3
              </div>
              <div>
                <p className="font-medium">Créez le fichier .env.local et collez le contenu ci-dessus</p>
                <code className="text-blue-400 text-sm">touch .env.local</code>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold mt-0.5">
                4
              </div>
              <div>
                <p className="font-medium">Installez les dépendances et démarrez</p>
                <code className="text-blue-400 text-sm">npm install && npm run dev</code>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-white text-sm font-bold mt-0.5">
                ✓
              </div>
              <div>
                <p className="font-medium">Ouvrez http://localhost:3000 dans votre navigateur</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
