import nodemailer from "nodemailer"

const transporter = nodemailer.createTransporter({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
})

export async function sendVerificationEmail(email: string, token: string) {
  const verificationUrl = `${process.env.NEXTAUTH_URL}/auth/verify?token=${token}`

  const mailOptions = {
    from: process.env.SMTP_USER,
    to: email,
    subject: "Vérifiez votre compte DPC'asino",
    html: `
      <div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
        <div style="background: linear-gradient(135deg, #1e293b 0%, #3b82f6 100%); padding: 30px; text-align: center;">
          <h1 style="color: #fbbf24; margin: 0; font-size: 32px;">DPC'asino</h1>
          <p style="color: white; margin: 10px 0 0 0;">Casino multijoueur sécurisé</p>
        </div>
        
        <div style="padding: 30px; background: #f8fafc;">
          <h2 style="color: #1e293b; margin-bottom: 20px;">Bienvenue au DPC'asino !</h2>
          
          <p style="color: #475569; line-height: 1.6;">
            Merci de vous être inscrit sur notre plateforme. Pour activer votre compte et commencer à jouer, 
            veuillez cliquer sur le bouton ci-dessous :
          </p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${verificationUrl}" 
               style="background: linear-gradient(135deg, #3b82f6, #8b5cf6); 
                      color: white; 
                      padding: 15px 30px; 
                      text-decoration: none; 
                      border-radius: 8px; 
                      font-weight: bold;
                      display: inline-block;">
              Vérifier mon compte
            </a>
          </div>
          
          <p style="color: #64748b; font-size: 14px; margin-top: 30px;">
            Ce lien expire dans 24 heures. Si vous n'avez pas créé de compte, ignorez cet email.
          </p>
          
          <div style="border-top: 1px solid #e2e8f0; margin-top: 30px; padding-top: 20px;">
            <p style="color: #64748b; font-size: 12px; margin: 0;">
              © 2024 DPC'asino - Casino multijoueur sécurisé
            </p>
          </div>
        </div>
      </div>
    `,
  }

  await transporter.sendMail(mailOptions)
}

export async function sendPasswordResetEmail(email: string, token: string) {
  const resetUrl = `${process.env.NEXTAUTH_URL}/auth/reset-password?token=${token}`

  const mailOptions = {
    from: process.env.SMTP_USER,
    to: email,
    subject: "Réinitialisation de votre mot de passe DPC'asino",
    html: `
      <div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
        <div style="background: linear-gradient(135deg, #1e293b 0%, #ef4444 100%); padding: 30px; text-align: center;">
          <h1 style="color: #fbbf24; margin: 0; font-size: 32px;">DPC'asino</h1>
          <p style="color: white; margin: 10px 0 0 0;">Réinitialisation de mot de passe</p>
        </div>
        
        <div style="padding: 30px; background: #f8fafc;">
          <h2 style="color: #1e293b; margin-bottom: 20px;">Réinitialiser votre mot de passe</h2>
          
          <p style="color: #475569; line-height: 1.6;">
            Vous avez demandé la réinitialisation de votre mot de passe. 
            Cliquez sur le bouton ci-dessous pour créer un nouveau mot de passe :
          </p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${resetUrl}" 
               style="background: linear-gradient(135deg, #ef4444, #f97316); 
                      color: white; 
                      padding: 15px 30px; 
                      text-decoration: none; 
                      border-radius: 8px; 
                      font-weight: bold;
                      display: inline-block;">
              Réinitialiser mon mot de passe
            </a>
          </div>
          
          <p style="color: #64748b; font-size: 14px; margin-top: 30px;">
            Ce lien expire dans 1 heure. Si vous n'avez pas demandé cette réinitialisation, ignorez cet email.
          </p>
        </div>
      </div>
    `,
  }

  await transporter.sendMail(mailOptions)
}
