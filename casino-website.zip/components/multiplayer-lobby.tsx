"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Users, Play, Crown, Zap, Globe, Lock } from "lucide-react"

interface MultiplayerLobbyProps {
  user: any
  onJoinGame: (gameType: string, roomId: string) => void
  onClose: () => void
}

export default function MultiplayerLobby({ user, onJoinGame, onClose }: MultiplayerLobbyProps) {
  const [activeRooms, setActiveRooms] = useState<any[]>([])
  const [selectedGame, setSelectedGame] = useState("poker")

  // Simulation de salles actives
  useEffect(() => {
    const generateRooms = () => {
      const games = ["poker", "blackjack", "roulette"]
      const rooms = []

      for (let i = 0; i < 12; i++) {
        const game = games[Math.floor(Math.random() * games.length)]
        const players = Math.floor(Math.random() * 6) + 1
        const maxPlayers = game === "poker" ? 6 : game === "blackjack" ? 4 : 8
        const minBet = [10, 25, 50, 100][Math.floor(Math.random() * 4)]

        rooms.push({
          id: `room_${i + 1}`,
          game,
          name: `${game.charAt(0).toUpperCase() + game.slice(1)} Room ${i + 1}`,
          players,
          maxPlayers,
          minBet,
          status: players < maxPlayers ? "waiting" : "playing",
          isPrivate: Math.random() < 0.2,
          level: Math.floor(Math.random() * 5) + 1,
          host: `Player${Math.floor(Math.random() * 1000)}`,
        })
      }

      setActiveRooms(rooms)
    }

    generateRooms()
    const interval = setInterval(generateRooms, 5000) // Mise à jour toutes les 5 secondes

    return () => clearInterval(interval)
  }, [])

  const filteredRooms = activeRooms.filter((room) => room.game === selectedGame)

  const createRoom = () => {
    const newRoom = {
      id: `room_${Date.now()}`,
      game: selectedGame,
      name: `${user.username}'s Room`,
      players: 1,
      maxPlayers: selectedGame === "poker" ? 6 : selectedGame === "blackjack" ? 4 : 8,
      minBet: 25,
      status: "waiting",
      isPrivate: false,
      level: user.level || 1,
      host: user.username,
    }

    onJoinGame(selectedGame, newRoom.id)
  }

  const getRankColor = (level: number) => {
    if (level <= 1) return "text-orange-400"
    if (level <= 2) return "text-gray-300"
    if (level <= 3) return "text-yellow-400"
    if (level <= 4) return "text-cyan-400"
    return "text-purple-400"
  }

  const getGameIcon = (game: string) => {
    switch (game) {
      case "poker":
        return "♠️"
      case "blackjack":
        return "🃏"
      case "roulette":
        return "🎯"
      default:
        return "🎮"
    }
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white flex items-center">
          <Globe className="w-8 h-8 mr-3 text-blue-400" />
          Multijoueur
        </h2>
        <Button onClick={onClose} variant="outline" className="border-slate-600 text-slate-300">
          Retour
        </Button>
      </div>

      {/* Player Info */}
      <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <img src={user.avatar || "/placeholder.svg"} alt="Avatar" className="w-12 h-12 rounded-full" />
            <div>
              <div className="text-lg font-bold text-white">{user.username}</div>
              <div className="flex items-center space-x-2">
                <Badge className={getRankColor(user.level)}>Niveau {user.level}</Badge>
                <Badge variant="outline" className="border-yellow-400 text-yellow-400">
                  {user.credits} crédits
                </Badge>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-slate-400">Parties jouées</div>
            <div className="text-xl font-bold text-white">{user.stats?.gamesPlayed || 0}</div>
          </div>
        </div>
      </div>

      {/* Game Selection */}
      <div className="flex space-x-4">
        {["poker", "blackjack", "roulette"].map((game) => (
          <Button
            key={game}
            variant={selectedGame === game ? "default" : "outline"}
            onClick={() => setSelectedGame(game)}
            className={`flex items-center space-x-2 ${
              selectedGame === game ? "bg-blue-600 hover:bg-blue-700" : "border-slate-600"
            }`}
          >
            <span className="text-xl">{getGameIcon(game)}</span>
            <span>{game.charAt(0).toUpperCase() + game.slice(1)}</span>
          </Button>
        ))}
      </div>

      {/* Create Room */}
      <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-xl font-bold text-white">Créer une nouvelle partie</h3>
            <p className="text-slate-400">Hébergez votre propre table de {selectedGame}</p>
          </div>
          <Button onClick={createRoom} className="bg-green-600 hover:bg-green-700">
            <Play className="w-4 h-4 mr-2" />
            Créer une partie
          </Button>
        </div>
      </div>

      {/* Active Rooms */}
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-white flex items-center">
          <Users className="w-5 h-5 mr-2" />
          Parties disponibles ({filteredRooms.length})
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredRooms.map((room) => (
            <div
              key={room.id}
              className="bg-slate-800/50 rounded-xl p-4 border border-slate-700 hover:border-slate-600 transition-colors"
            >
              <div className="space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xl">{getGameIcon(room.game)}</span>
                      <h4 className="font-bold text-white">{room.name}</h4>
                      {room.isPrivate && <Lock className="w-4 h-4 text-yellow-400" />}
                    </div>
                    <div className="text-sm text-slate-400">Hôte: {room.host}</div>
                  </div>
                  <Badge
                    variant={room.status === "waiting" ? "default" : "secondary"}
                    className={room.status === "waiting" ? "bg-green-600" : "bg-red-600"}
                  >
                    {room.status === "waiting" ? "En attente" : "En cours"}
                  </Badge>
                </div>

                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-slate-400" />
                    <span className="text-sm text-slate-300">
                      {room.players}/{room.maxPlayers}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Crown className={`w-4 h-4 ${getRankColor(room.level)}`} />
                    <span className="text-sm text-slate-300">Niv. {room.level}</span>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <div className="text-sm text-slate-400">
                    Mise min: <span className="text-yellow-400">{room.minBet}</span>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => onJoinGame(room.game, room.id)}
                    disabled={room.status === "playing" || room.players >= room.maxPlayers}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Rejoindre
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredRooms.length === 0 && (
          <div className="text-center py-8">
            <div className="text-slate-400 mb-4">Aucune partie disponible pour {selectedGame}</div>
            <Button onClick={createRoom} className="bg-green-600 hover:bg-green-700">
              Créer la première partie
            </Button>
          </div>
        )}
      </div>

      {/* Quick Match */}
      <div className="bg-gradient-to-r from-blue-900/50 to-purple-900/50 rounded-xl p-6 border border-blue-500/30">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-xl font-bold text-white flex items-center">
              <Zap className="w-5 h-5 mr-2 text-yellow-400" />
              Partie Rapide
            </h3>
            <p className="text-slate-400">Rejoignez automatiquement une partie de votre niveau</p>
          </div>
          <Button
            onClick={() => {
              const availableRooms = filteredRooms.filter((room) => room.status === "waiting")
              if (availableRooms.length > 0) {
                const randomRoom = availableRooms[Math.floor(Math.random() * availableRooms.length)]
                onJoinGame(randomRoom.game, randomRoom.id)
              } else {
                createRoom()
              }
            }}
            className="bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700"
          >
            <Zap className="w-4 h-4 mr-2" />
            Partie Rapide
          </Button>
        </div>
      </div>
    </div>
  )
}
