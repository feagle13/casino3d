"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Users, Clock, Crown, Zap } from "lucide-react"

interface PokerTableProps {
  credits: number
  setCredits: (credits: number) => void
  playerRank?: string
  onGameEnd?: (won: boolean, lpChange: number) => void
}

interface Player {
  id: string
  name: string
  avatar: string
  chips: number
  level: number
  isReady: boolean
}

export default function PokerTable({ credits, setCredits, playerRank, onGameEnd }: PokerTableProps) {
  const [gameState, setGameState] = useState<"waiting" | "ready" | "playing">("waiting")
  const [players, setPlayers] = useState<Player[]>([])
  const [waitingTime, setWaitingTime] = useState(0)
  const [roomId] = useState(`poker_${Math.random().toString(36).substr(2, 9)}`)
  const [isReady, setIsReady] = useState(false)
  const [minBet] = useState(25)
  const [maxPlayers] = useState(6)

  // Simulation de joueurs qui rejoignent
  useEffect(() => {
    const interval = setInterval(() => {
      setWaitingTime((prev) => prev + 1)

      // Simulation de joueurs qui rejoignent aléatoirement
      if (players.length < maxPlayers && Math.random() < 0.3) {
        const newPlayer: Player = {
          id: `player_${Math.random().toString(36).substr(2, 9)}`,
          name: `Joueur${Math.floor(Math.random() * 1000)}`,
          avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${Math.random()}`,
          chips: Math.floor(Math.random() * 2000) + 500,
          level: Math.floor(Math.random() * 5) + 1,
          isReady: Math.random() < 0.7,
        }

        setPlayers((prev) => [...prev, newPlayer])
      }

      // Simulation de joueurs qui partent
      if (players.length > 1 && Math.random() < 0.1) {
        setPlayers((prev) => prev.slice(0, -1))
      }

      // Simulation de joueurs qui changent leur statut ready
      if (players.length > 0 && Math.random() < 0.2) {
        setPlayers((prev) =>
          prev.map((player) => (Math.random() < 0.3 ? { ...player, isReady: !player.isReady } : player)),
        )
      }
    }, 2000)

    return () => clearInterval(interval)
  }, [players.length, maxPlayers])

  // Vérifier si la partie peut commencer
  useEffect(() => {
    const readyPlayers = players.filter((p) => p.isReady).length + (isReady ? 1 : 0)
    if (readyPlayers >= 2 && players.length >= 1) {
      setGameState("ready")
    } else {
      setGameState("waiting")
    }
  }, [players, isReady])

  const toggleReady = () => {
    setIsReady(!isReady)
  }

  const startGame = () => {
    setGameState("playing")
    // Ici on démarrerait la vraie partie de poker multijoueur
  }

  const leaveTable = () => {
    // Retour au lobby
    window.history.back()
  }

  const getRankColor = (level: number) => {
    if (level <= 1) return "text-orange-400"
    if (level <= 2) return "text-gray-300"
    if (level <= 3) return "text-yellow-400"
    if (level <= 4) return "text-cyan-400"
    return "text-purple-400"
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  if (gameState === "playing") {
    return (
      <div className="text-white space-y-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold mb-4">Partie en cours...</h2>
          <p className="text-slate-300 mb-8">Le système de poker multijoueur sera bientôt disponible!</p>
          <Button onClick={leaveTable} className="bg-red-600 hover:bg-red-700">
            Quitter la table
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="text-white space-y-6">
      {/* Room Info */}
      <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">Table de Poker</h2>
            <div className="flex items-center space-x-4 text-sm text-slate-300">
              <span>Salle: {roomId}</span>
              <span>Mise min: {minBet} crédits</span>
              <span>Texas Hold'em</span>
            </div>
          </div>
          <div className="text-right">
            <div className="flex items-center space-x-2 mb-2">
              <Clock className="w-4 h-4" />
              <span>Temps d'attente: {formatTime(waitingTime)}</span>
            </div>
            <Badge
              variant={gameState === "ready" ? "default" : "secondary"}
              className={gameState === "ready" ? "bg-green-600" : "bg-yellow-600"}
            >
              {gameState === "ready" ? "Prêt à commencer" : "En attente de joueurs"}
            </Badge>
          </div>
        </div>
      </div>

      {/* Players Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {/* Current Player */}
        <div className="bg-blue-900/50 rounded-xl p-4 border-2 border-blue-400">
          <div className="text-center space-y-3">
            <div className="w-16 h-16 bg-blue-600 rounded-full mx-auto flex items-center justify-center">
              <span className="text-2xl">👤</span>
            </div>
            <div>
              <div className="font-bold">Vous</div>
              <div className="text-sm text-slate-300">{credits} crédits</div>
              <Badge className={getRankColor(1)}>Niveau 1</Badge>
            </div>
            <Button
              onClick={toggleReady}
              size="sm"
              className={isReady ? "bg-green-600 hover:bg-green-700" : "bg-gray-600 hover:bg-gray-700"}
            >
              {isReady ? "Prêt ✓" : "Pas prêt"}
            </Button>
          </div>
        </div>

        {/* Other Players */}
        {players.map((player) => (
          <div key={player.id} className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <div className="text-center space-y-3">
              <img
                src={player.avatar || "/placeholder.svg"}
                alt={player.name}
                className="w-16 h-16 rounded-full mx-auto"
              />
              <div>
                <div className="font-bold">{player.name}</div>
                <div className="text-sm text-slate-300">{player.chips} crédits</div>
                <Badge className={getRankColor(player.level)}>Niveau {player.level}</Badge>
              </div>
              <Badge
                variant={player.isReady ? "default" : "secondary"}
                className={player.isReady ? "bg-green-600" : "bg-gray-600"}
              >
                {player.isReady ? "Prêt ✓" : "En attente"}
              </Badge>
            </div>
          </div>
        ))}

        {/* Empty Slots */}
        {Array.from({ length: maxPlayers - players.length - 1 }, (_, index) => (
          <div
            key={`empty-${index}`}
            className="bg-slate-700/30 rounded-xl p-4 border-2 border-dashed border-slate-600"
          >
            <div className="text-center space-y-3">
              <div className="w-16 h-16 bg-slate-600 rounded-full mx-auto flex items-center justify-center">
                <Users className="w-8 h-8 text-slate-400" />
              </div>
              <div className="text-slate-400">
                <div className="font-bold">En attente</div>
                <div className="text-sm">d'un joueur</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Game Status */}
      <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-2">
            <Users className="w-6 h-6 text-blue-400" />
            <span className="text-xl font-bold">
              {players.length + 1}/{maxPlayers} joueurs
            </span>
          </div>

          <div className="flex items-center justify-center space-x-2">
            <Crown className="w-6 h-6 text-green-400" />
            <span className="text-lg">{players.filter((p) => p.isReady).length + (isReady ? 1 : 0)} joueurs prêts</span>
          </div>

          {gameState === "ready" ? (
            <div className="space-y-4">
              <div className="text-green-400 font-bold text-lg">
                🎉 Assez de joueurs prêts! La partie peut commencer.
              </div>
              <Button onClick={startGame} className="bg-green-600 hover:bg-green-700 text-xl px-8 py-4">
                <Zap className="w-5 h-5 mr-2" />
                Commencer la partie
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="text-yellow-400">En attente de plus de joueurs prêts...</div>
              <div className="text-sm text-slate-400">Minimum 2 joueurs prêts requis pour commencer</div>
            </div>
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="flex justify-center space-x-4">
        <Button
          onClick={leaveTable}
          variant="outline"
          className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
        >
          Quitter la table
        </Button>
      </div>

      {/* Info */}
      <div className="bg-blue-900/20 rounded-xl p-4 border border-blue-500/30">
        <div className="text-center text-sm text-blue-300">
          <p className="mb-2">
            🎮 <strong>Poker multijoueur en temps réel</strong>
          </p>
          <p>Les joueurs rejoignent automatiquement. Cliquez sur "Prêt" quand vous voulez commencer!</p>
        </div>
      </div>
    </div>
  )
}
