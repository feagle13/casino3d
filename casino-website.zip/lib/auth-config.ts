// Configuration pour NextAuth.js (à utiliser en production)

export const authConfig = {
  providers: [
    // Google OAuth
    {
      id: "google",
      name: "Google",
      type: "oauth",
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      authorization: {
        params: {
          scope: "openid email profile",
        },
      },
    },
    // Email/Password
    {
      id: "credentials",
      name: "credentials",
      type: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials: any) {
        // Validation et authentification sécurisée
        if (!credentials?.email || !credentials?.password) {
          return null
        }

        // Vérifier en base de données
        // const user = await verifyUser(credentials.email, credentials.password)

        return {
          id: "1",
          email: credentials.email,
          name: "User",
        }
      },
    },
  ],
  session: {
    strategy: "jwt" as const,
    maxAge: 30 * 24 * 60 * 60, // 30 jours
  },
  callbacks: {
    async jwt({ token, user }: any) {
      if (user) {
        token.id = user.id
      }
      return token
    },
    async session({ session, token }: any) {
      session.user.id = token.id
      return session
    },
  },
  pages: {
    signIn: "/auth/signin",
    signUp: "/auth/signup",
    error: "/auth/error",
  },
}
