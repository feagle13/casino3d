import NextAuth, { type NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"

export const authOptions: NextAuthOptions = {
  providers: [
    // Authentification par email/mot de passe uniquement
    CredentialsProvider({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null
        }

        // Comptes de démonstration
        const demoAccounts = [
          { email: "demo@example.com", password: "demo123", name: "Demo User" },
          { email: "admin@dpcasino.com", password: "admin123", name: "Admin" },
          { email: "player@test.com", password: "player123", name: "Test Player" },
          { email: "vip@casino.com", password: "vip123", name: "VIP Player" },
          { email: "pro@poker.com", password: "pro123", name: "Poker Pro" },
        ]

        const user = demoAccounts.find(
          (account) => account.email === credentials.email && account.password === credentials.password,
        )

        if (user) {
          return {
            id: Math.random().toString(36).substr(2, 9),
            email: user.email,
            name: user.name,
            image: `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.name}`,
          }
        }

        return null
      },
    }),
  ],
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 jours
  },
  pages: {
    signIn: "/auth/signin",
    error: "/auth/error",
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
      }
      return token
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.id as string
      }
      return session
    },
  },
  secret: process.env.NEXTAUTH_SECRET,
}

const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }
