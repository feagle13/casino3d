"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Calendar, Gift, Coins, Star, Crown, Zap } from "lucide-react"

interface DailyRewardsProps {
  user: any
  onClaimReward: (reward: any) => void
  onClose: () => void
}

export default function DailyRewards({ user, onClaimReward, onClose }: DailyRewardsProps) {
  const [currentDay, setCurrentDay] = useState(1)
  const [canClaim, setCanClaim] = useState(true)
  const [timeUntilNext, setTimeUntilNext] = useState("")

  const rewards = [
    { day: 1, type: "credits", amount: 100, icon: Coins, color: "text-yellow-400", bg: "bg-yellow-400/20" },
    { day: 2, type: "credits", amount: 150, icon: Coins, color: "text-yellow-400", bg: "bg-yellow-400/20" },
    { day: 3, type: "experience", amount: 50, icon: Star, color: "text-blue-400", bg: "bg-blue-400/20" },
    { day: 4, type: "credits", amount: 200, icon: Coins, color: "text-yellow-400", bg: "bg-yellow-400/20" },
    { day: 5, type: "credits", amount: 300, icon: Coins, color: "text-yellow-400", bg: "bg-yellow-400/20" },
    { day: 6, type: "experience", amount: 100, icon: Star, color: "text-blue-400", bg: "bg-blue-400/20" },
    { day: 7, type: "jackpot", amount: 1000, icon: Crown, color: "text-purple-400", bg: "bg-purple-400/20" },
  ]

  useEffect(() => {
    // Vérifier si le joueur peut récupérer sa récompense
    const lastClaim = user.dailyRewards?.lastClaim
    const now = new Date()

    if (lastClaim) {
      const lastClaimDate = new Date(lastClaim)
      const timeDiff = now.getTime() - lastClaimDate.getTime()
      const hoursDiff = timeDiff / (1000 * 3600)

      if (hoursDiff < 24) {
        setCanClaim(false)
        // Calculer le temps restant
        const hoursLeft = 24 - hoursDiff
        const hours = Math.floor(hoursLeft)
        const minutes = Math.floor((hoursLeft - hours) * 60)
        setTimeUntilNext(`${hours}h ${minutes}m`)
      } else {
        setCanClaim(true)
      }
    }

    // Déterminer le jour actuel de la streak
    const streak = user.dailyRewards?.streak || 0
    setCurrentDay((streak % 7) + 1)
  }, [user])

  const claimReward = () => {
    const todayReward = rewards[currentDay - 1]
    const reward = {
      ...todayReward,
      timestamp: new Date().toISOString(),
    }

    onClaimReward(reward)
    setCanClaim(false)

    // Calculer le temps jusqu'à la prochaine récompense
    setTimeUntilNext("23h 59m")
  }

  const playSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)

      oscillator.frequency.setValueAtTime(600, audioContext.currentTime)
      oscillator.type = "sine"

      gainNode.gain.setValueAtTime(0.1, audioContext.currentTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5)

      oscillator.start(audioContext.currentTime)
      oscillator.stop(audioContext.currentTime + 0.5)
    } catch (error) {
      console.log("Audio not available")
    }
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white flex items-center">
          <Calendar className="w-8 h-8 mr-3 text-green-400" />
          Récompenses Quotidiennes
        </h2>
        <Button onClick={onClose} variant="outline" className="border-slate-600 text-slate-300">
          Fermer
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
          <div className="flex items-center space-x-3">
            <Zap className="w-8 h-8 text-orange-400" />
            <div>
              <div className="text-2xl font-bold text-white">{user.dailyRewards?.streak || 0}</div>
              <div className="text-sm text-slate-400">Jours consécutifs</div>
            </div>
          </div>
        </div>
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
          <div className="flex items-center space-x-3">
            <Gift className="w-8 h-8 text-purple-400" />
            <div>
              <div className="text-2xl font-bold text-white">{user.dailyRewards?.totalClaimed || 0}</div>
              <div className="text-sm text-slate-400">Récompenses récupérées</div>
            </div>
          </div>
        </div>
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
          <div className="flex items-center space-x-3">
            <Crown className="w-8 h-8 text-yellow-400" />
            <div>
              <div className="text-2xl font-bold text-white">Jour {currentDay}</div>
              <div className="text-sm text-slate-400">Récompense actuelle</div>
            </div>
          </div>
        </div>
      </div>

      {/* Calendar */}
      <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
        <h3 className="text-xl font-bold text-white mb-6 text-center">Calendrier des Récompenses</h3>

        <div className="grid grid-cols-7 gap-4">
          {rewards.map((reward, index) => {
            const day = index + 1
            const isCurrent = day === currentDay
            const isCompleted = day < currentDay || (day === currentDay && !canClaim)
            const IconComponent = reward.icon

            return (
              <div
                key={day}
                className={`relative p-4 rounded-xl border-2 transition-all ${
                  isCurrent && canClaim
                    ? "border-green-400 bg-green-400/10 scale-105"
                    : isCompleted
                      ? "border-gray-600 bg-gray-600/10"
                      : "border-slate-600 bg-slate-700/50"
                }`}
              >
                <div className="text-center space-y-2">
                  <div className="text-sm font-bold text-slate-300">Jour {day}</div>

                  <div className={`w-12 h-12 rounded-full ${reward.bg} flex items-center justify-center mx-auto`}>
                    <IconComponent className={`w-6 h-6 ${reward.color}`} />
                  </div>

                  <div className="space-y-1">
                    <div className="text-xs text-slate-400">
                      {reward.type === "credits" ? "Crédits" : reward.type === "experience" ? "XP" : "Jackpot"}
                    </div>
                    <div className={`text-sm font-bold ${reward.color}`}>{reward.amount}</div>
                  </div>

                  {isCompleted && (
                    <div className="absolute -top-2 -right-2">
                      <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-xs">✓</span>
                      </div>
                    </div>
                  )}

                  {isCurrent && canClaim && (
                    <div className="absolute -top-2 -right-2">
                      <div className="w-6 h-6 bg-yellow-400 rounded-full animate-pulse"></div>
                    </div>
                  )}
                </div>
              </div>
            )
          })}
        </div>

        {/* Claim Button */}
        <div className="mt-8 text-center">
          {canClaim ? (
            <Button
              onClick={() => {
                claimReward()
                playSound()
              }}
              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold px-8 py-4 text-lg"
            >
              <Gift className="w-5 h-5 mr-2" />
              Récupérer la récompense du jour {currentDay}
            </Button>
          ) : (
            <div className="space-y-2">
              <Button disabled className="bg-gray-600 text-gray-400 px-8 py-4 text-lg">
                <Gift className="w-5 h-5 mr-2" />
                Récompense déjà récupérée
              </Button>
              {timeUntilNext && (
                <div className="text-sm text-slate-400">Prochaine récompense dans: {timeUntilNext}</div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Bonus Info */}
      <div className="bg-gradient-to-r from-purple-900/50 to-blue-900/50 rounded-xl p-6 border border-purple-500/30">
        <h4 className="text-lg font-bold text-white mb-3 flex items-center">
          <Star className="w-5 h-5 mr-2 text-yellow-400" />
          Bonus de Streak
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div className="text-center">
            <div className="text-yellow-400 font-bold">7 jours</div>
            <div className="text-slate-300">+50% de bonus</div>
          </div>
          <div className="text-center">
            <div className="text-orange-400 font-bold">14 jours</div>
            <div className="text-slate-300">+100% de bonus</div>
          </div>
          <div className="text-center">
            <div className="text-red-400 font-bold">30 jours</div>
            <div className="text-slate-300">Récompense spéciale</div>
          </div>
        </div>
      </div>
    </div>
  )
}
