"use client"

import { Suspense, useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Coins, Trophy, Settings, Globe, Gift } from "lucide-react"
import BlackjackTable from "@/components/blackjack-table"
import RouletteTable from "@/components/roulette-table"
import SlotMachine from "@/components/slot-machine"
import PokerTable from "@/components/poker-table"
import SettingsPanel from "@/components/settings-panel"
import RankingSystem from "@/components/ranking-system"
import AuthSystem from "@/components/auth-system"
import DailyRewards from "@/components/daily-rewards"
import MultiplayerLobby from "@/components/multiplayer-lobby"

interface PlayerStats {
  blackjack: { rank: string; lp: number; wins: number; losses: number }
  roulette: { rank: string; lp: number; wins: number; losses: number }
  slots: { rank: string; lp: number; wins: number; losses: number }
  poker: { rank: string; lp: number; wins: number; losses: number }
}

export default function DPCasinoPage() {
  const [user, setUser] = useState<any>(null)
  const [selectedGame, setSelectedGame] = useState<string | null>(null)
  const [showSettings, setShowSettings] = useState(false)
  const [showRanking, setShowRanking] = useState(false)
  const [showDailyRewards, setShowDailyRewards] = useState(false)
  const [showMultiplayer, setShowMultiplayer] = useState(false)
  const [currentRoom, setCurrentRoom] = useState<string | null>(null)
  const [playerStats, setPlayerStats] = useState<PlayerStats>({
    blackjack: { rank: "Bronze III", lp: 45, wins: 12, losses: 8 },
    roulette: { rank: "Silver I", lp: 78, wins: 23, losses: 15 },
    slots: { rank: "Bronze I", lp: 23, wins: 8, losses: 12 },
    poker: { rank: "Gold IV", lp: 156, wins: 34, losses: 21 },
  })

  const games = [
    {
      id: "blackjack",
      name: "Blackjack",
      description: "Jeu de cartes classique",
      color: "from-green-600 to-green-800",
      icon: "🃏",
    },
    {
      id: "roulette",
      name: "Roulette",
      description: "Roulette européenne",
      color: "from-red-600 to-red-800",
      icon: "🎯",
    },
    {
      id: "slots",
      name: "Machine à sous",
      description: "Slots avec jackpots",
      color: "from-yellow-600 to-yellow-800",
      icon: "🎰",
    },
    {
      id: "poker",
      name: "Poker",
      description: "Texas Hold'em multijoueur",
      color: "from-blue-600 to-blue-800",
      icon: "♠️",
    },
  ]

  const getRankColor = (rank: string) => {
    if (rank.includes("Bronze")) return "text-orange-400"
    if (rank.includes("Silver")) return "text-gray-300"
    if (rank.includes("Gold")) return "text-yellow-400"
    if (rank.includes("Platinum")) return "text-cyan-400"
    if (rank.includes("Diamond")) return "text-blue-400"
    if (rank.includes("Master")) return "text-purple-400"
    if (rank.includes("Grandmaster")) return "text-red-400"
    return "text-white"
  }

  const updatePlayerStats = (game: keyof PlayerStats, won: boolean, lpChange: number) => {
    setPlayerStats((prev) => ({
      ...prev,
      [game]: {
        ...prev[game],
        wins: won ? prev[game].wins + 1 : prev[game].wins,
        losses: won ? prev[game].losses : prev[game].losses + 1,
        lp: Math.max(0, prev[game].lp + lpChange),
      },
    }))
  }

  const handleLogin = (userData: any) => {
    setUser(userData)
  }

  const handleClaimReward = (reward: any) => {
    setUser((prev: any) => ({
      ...prev,
      credits: prev.credits + (reward.type === "credits" ? reward.amount : 0),
      experience: prev.experience + (reward.type === "experience" ? reward.amount : 0),
      dailyRewards: {
        ...prev.dailyRewards,
        lastClaim: reward.timestamp,
        streak: prev.dailyRewards.streak + 1,
        totalClaimed: prev.dailyRewards.totalClaimed + 1,
      },
    }))
  }

  const handleJoinGame = (gameType: string, roomId: string) => {
    setCurrentRoom(roomId)
    setSelectedGame(gameType)
    setShowMultiplayer(false)
  }

  const canClaimDailyReward = () => {
    if (!user?.dailyRewards?.lastClaim) return true
    const lastClaim = new Date(user.dailyRewards.lastClaim)
    const now = new Date()
    const timeDiff = now.getTime() - lastClaim.getTime()
    const hoursDiff = timeDiff / (1000 * 3600)
    return hoursDiff >= 24
  }

  if (!user) {
    return <AuthSystem onLogin={handleLogin} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700/50 backdrop-blur-sm bg-black/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                  <span className="text-black font-bold text-lg">D</span>
                </div>
                <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
                  DPC'asino
                </h1>
              </div>
              <div className="flex items-center space-x-2">
                <img src={user.avatar || "/placeholder.svg"} alt="Avatar" className="w-8 h-8 rounded-full" />
                <span className="text-white font-medium">{user.username}</span>
              </div>
              <Badge variant="secondary" className="bg-yellow-400/20 text-yellow-400 border-yellow-400/30">
                <Coins className="w-4 h-4 mr-1" />
                {user.credits} crédits
              </Badge>
            </div>

            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                className="border-slate-600 text-slate-300"
                onClick={() => setShowMultiplayer(true)}
              >
                <Globe className="w-4 h-4 mr-1" />
                Multijoueur
              </Button>
              <Button
                variant="outline"
                size="sm"
                className={`border-slate-600 text-slate-300 ${canClaimDailyReward() ? "animate-pulse border-green-400 text-green-400" : ""}`}
                onClick={() => setShowDailyRewards(true)}
              >
                <Gift className="w-4 h-4 mr-1" />
                {canClaimDailyReward() ? "Récompense!" : "Calendrier"}
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="border-slate-600 text-slate-300"
                onClick={() => setShowRanking(true)}
              >
                <Trophy className="w-4 h-4 mr-1" />
                Classements
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="border-slate-600 text-slate-300"
                onClick={() => setShowSettings(true)}
              >
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Casino Floor */}
      <main className="container mx-auto px-4 py-8">
        {showSettings ? (
          <SettingsPanel onClose={() => setShowSettings(false)} />
        ) : showRanking ? (
          <RankingSystem playerStats={playerStats} onClose={() => setShowRanking(false)} />
        ) : showDailyRewards ? (
          <DailyRewards user={user} onClaimReward={handleClaimReward} onClose={() => setShowDailyRewards(false)} />
        ) : showMultiplayer ? (
          <MultiplayerLobby user={user} onJoinGame={handleJoinGame} onClose={() => setShowMultiplayer(false)} />
        ) : !selectedGame ? (
          <>
            {/* Welcome Section */}
            <div className="text-center mb-12">
              <h2 className="text-5xl font-bold text-white mb-4">Bienvenue au DPC'asino</h2>
              <p className="text-xl text-slate-300 mb-8">
                Casino multijoueur en ligne avec système de ranking compétitif
              </p>
              <div className="flex justify-center space-x-8 text-center">
                <div className="text-white">
                  <div className="text-3xl font-bold text-yellow-400">24/7</div>
                  <div className="text-sm">En ligne</div>
                </div>
                <div className="text-white">
                  <div className="text-3xl font-bold text-green-400">247</div>
                  <div className="text-sm">Joueurs connectés</div>
                </div>
                <div className="text-white">
                  <div className="text-3xl font-bold text-blue-400">{user.level}</div>
                  <div className="text-sm">Votre niveau</div>
                </div>
              </div>
            </div>

            {/* Daily Reward Notification */}
            {canClaimDailyReward() && (
              <div className="mb-8">
                <div className="bg-gradient-to-r from-green-900/50 to-emerald-900/50 rounded-xl p-6 border border-green-500/30">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-4">
                      <Gift className="w-8 h-8 text-green-400" />
                      <div>
                        <h3 className="text-xl font-bold text-white">Récompense quotidienne disponible!</h3>
                        <p className="text-green-300">Récupérez vos crédits gratuits maintenant</p>
                      </div>
                    </div>
                    <Button
                      onClick={() => setShowDailyRewards(true)}
                      className="bg-green-600 hover:bg-green-700 animate-pulse"
                    >
                      Récupérer
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {/* Games Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              {games.map((game) => (
                <div
                  key={game.id}
                  className={`relative group cursor-pointer transform transition-all duration-300 hover:scale-105 hover:z-10`}
                  onClick={() => setSelectedGame(game.id)}
                >
                  <div
                    className={`bg-gradient-to-br ${game.color} rounded-xl p-6 h-64 flex flex-col justify-between shadow-2xl border border-white/10`}
                  >
                    <div className="text-center">
                      <div className="text-6xl mb-4">{game.icon}</div>
                      <h3 className="text-2xl font-bold text-white mb-2">{game.name}</h3>
                      <p className="text-white/80">{game.description}</p>
                    </div>

                    {/* Rank Display */}
                    <div className="text-center space-y-2">
                      <div
                        className={`text-sm font-bold ${getRankColor(playerStats[game.id as keyof PlayerStats].rank)}`}
                      >
                        {playerStats[game.id as keyof PlayerStats].rank}
                      </div>
                      <div className="text-xs text-white/70">{playerStats[game.id as keyof PlayerStats].lp} LP</div>
                      <Button className="bg-white/20 hover:bg-white/30 text-white border-white/30">
                        Jouer maintenant
                      </Button>
                    </div>

                    {/* Hover effect */}
                    <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl"></div>
                  </div>
                </div>
              ))}
            </div>

            {/* Features */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              <div className="text-center p-6 bg-slate-800/50 rounded-xl border border-slate-700">
                <div className="text-4xl mb-4">🌐</div>
                <h3 className="text-xl font-bold text-white mb-2">Multijoueur</h3>
                <p className="text-slate-300">Jouez contre de vrais joueurs du monde entier</p>
              </div>
              <div className="text-center p-6 bg-slate-800/50 rounded-xl border border-slate-700">
                <div className="text-4xl mb-4">🎁</div>
                <h3 className="text-xl font-bold text-white mb-2">Récompenses</h3>
                <p className="text-slate-300">Crédits gratuits et bonus quotidiens</p>
              </div>
              <div className="text-center p-6 bg-slate-800/50 rounded-xl border border-slate-700">
                <div className="text-4xl mb-4">🏆</div>
                <h3 className="text-xl font-bold text-white mb-2">Compétition</h3>
                <p className="text-slate-300">Système de ranking et tournois</p>
              </div>
            </div>
          </>
        ) : (
          /* Game Interface */
          <div className="bg-slate-900/90 rounded-xl p-6 border border-slate-700">
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center space-x-4">
                <h2 className="text-3xl font-bold text-white">{games.find((g) => g.id === selectedGame)?.name}</h2>
                <Badge className={`${getRankColor(playerStats[selectedGame as keyof PlayerStats].rank)} bg-slate-800`}>
                  {playerStats[selectedGame as keyof PlayerStats].rank} -{" "}
                  {playerStats[selectedGame as keyof PlayerStats].lp} LP
                </Badge>
                {currentRoom && (
                  <Badge variant="outline" className="border-blue-400 text-blue-400">
                    Salle: {currentRoom}
                  </Badge>
                )}
              </div>
              <Button
                onClick={() => {
                  setSelectedGame(null)
                  setCurrentRoom(null)
                }}
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                Retour au casino
              </Button>
            </div>

            <Suspense
              fallback={
                <div className="flex items-center justify-center h-64">
                  <div className="text-white text-center">
                    <div className="animate-spin w-8 h-8 border-4 border-yellow-400 border-t-transparent rounded-full mx-auto mb-4"></div>
                    <p>Connexion aux joueurs...</p>
                  </div>
                </div>
              }
            >
              {selectedGame === "blackjack" && (
                <BlackjackTable
                  credits={user.credits}
                  setCredits={(credits) => setUser({ ...user, credits })}
                  playerRank={playerStats.blackjack.rank}
                  onGameEnd={(won, lpChange) => updatePlayerStats("blackjack", won, lpChange)}
                />
              )}
              {selectedGame === "roulette" && (
                <RouletteTable
                  credits={user.credits}
                  setCredits={(credits) => setUser({ ...user, credits })}
                  playerRank={playerStats.roulette.rank}
                  onGameEnd={(won, lpChange) => updatePlayerStats("roulette", won, lpChange)}
                />
              )}
              {selectedGame === "slots" && (
                <SlotMachine
                  credits={user.credits}
                  setCredits={(credits) => setUser({ ...user, credits })}
                  playerRank={playerStats.slots.rank}
                  onGameEnd={(won, lpChange) => updatePlayerStats("slots", won, lpChange)}
                />
              )}
              {selectedGame === "poker" && (
                <PokerTable
                  credits={user.credits}
                  setCredits={(credits) => setUser({ ...user, credits })}
                  playerRank={playerStats.poker.rank}
                  onGameEnd={(won, lpChange) => updatePlayerStats("poker", won, lpChange)}
                />
              )}
            </Suspense>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-700/50 mt-16 bg-black/20">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-slate-400">
            <div className="flex justify-center items-center space-x-2 mb-4">
              <div className="w-6 h-6 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                <span className="text-black font-bold text-sm">D</span>
              </div>
              <span className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
                DPC'asino
              </span>
            </div>
            <p>&copy; 2024 DPC'asino. Tous droits réservés.</p>
            <p className="text-sm mt-2">Casino multijoueur • Jeu responsable • 18+</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
