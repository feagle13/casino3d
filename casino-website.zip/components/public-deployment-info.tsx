"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Copy, Check, Globe, Users, Shield, Zap } from "lucide-react"

export default function PublicDeploymentInfo() {
  const [copiedUrl, setCopiedUrl] = useState(false)

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedUrl(true)
      setTimeout(() => setCopiedUrl(false), 2000)
    } catch (err) {
      console.error("Erreur de copie:", err)
    }
  }

  // URL d'exemple - à remplacer par la vraie URL après déploiement
  const publicUrl = "https://votre-casino.vercel.app"

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
              <span className="text-black font-bold text-2xl">D</span>
            </div>
            <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
              DPC'asino
            </h1>
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">Partage Public</h2>
          <p className="text-slate-300">Comment partager votre casino avec le monde</p>
        </div>

        {/* Current Status */}
        <div className="bg-gradient-to-r from-green-900/50 to-emerald-900/50 rounded-xl p-6 border border-green-500/30">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-white mb-4">🎉 Casino Prêt à Partager !</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-slate-800/50 rounded-lg p-4">
                <Shield className="w-8 h-8 text-green-400 mx-auto mb-2" />
                <div className="text-green-400 font-bold">Sécurisé</div>
                <div className="text-slate-300 text-sm">Comptes de test cachés</div>
              </div>
              <div className="bg-slate-800/50 rounded-lg p-4">
                <Users className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                <div className="text-blue-400 font-bold">Public</div>
                <div className="text-slate-300 text-sm">Interface utilisateur propre</div>
              </div>
              <div className="bg-slate-800/50 rounded-lg p-4">
                <Zap className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                <div className="text-purple-400 font-bold">Rapide</div>
                <div className="text-slate-300 text-sm">Optimisé pour la production</div>
              </div>
            </div>
          </div>
        </div>

        {/* URL de Partage */}
        <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center">
            <Globe className="w-5 h-5 mr-2 text-blue-400" />
            URL de Votre Casino
          </h3>

          <div className="space-y-4">
            <div className="bg-slate-900 rounded-lg p-4">
              <div className="flex justify-between items-center">
                <div>
                  <div className="text-sm text-slate-400 mb-1">Après déploiement, votre URL sera :</div>
                  <code className="text-green-400 text-lg">{publicUrl}</code>
                </div>
                <Button onClick={() => copyToClipboard(publicUrl)} className="bg-blue-600 hover:bg-blue-700">
                  {copiedUrl ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-blue-900/20 rounded-lg p-4 border border-blue-500/30">
                <h4 className="font-bold text-white mb-2">✅ Ce que verront les utilisateurs :</h4>
                <ul className="text-sm text-slate-300 space-y-1">
                  <li>• Interface de connexion propre</li>
                  <li>• Inscription gratuite (1000 crédits)</li>
                  <li>• Tous les jeux fonctionnels</li>
                  <li>• Système de ranking</li>
                  <li>• Récompenses quotidiennes</li>
                </ul>
              </div>

              <div className="bg-red-900/20 rounded-lg p-4 border border-red-500/30">
                <h4 className="font-bold text-white mb-2">❌ Ce qu'ils ne verront PAS :</h4>
                <ul className="text-sm text-slate-300 space-y-1">
                  <li>• Comptes de test visibles</li>
                  <li>• Bouton "Accès rapide"</li>
                  <li>• Informations de développement</li>
                  <li>• Configuration technique</li>
                  <li>• Mots de passe de démo</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Instructions de Déploiement */}
        <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
          <h3 className="text-xl font-bold text-white mb-4">🚀 Étapes pour Obtenir Votre URL</h3>

          <div className="space-y-4">
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                1
              </div>
              <div>
                <h4 className="font-bold text-white">Déployer sur Vercel</h4>
                <p className="text-slate-300 text-sm">Allez sur vercel.com et uploadez votre projet</p>
                <code className="text-green-400 text-sm">npx vercel --prod</code>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold">
                2
              </div>
              <div>
                <h4 className="font-bold text-white">Récupérer l'URL</h4>
                <p className="text-slate-300 text-sm">
                  Vercel vous donnera une URL comme :{" "}
                  <code className="text-blue-400">https://votre-casino-abc123.vercel.app</code>
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center text-white font-bold">
                3
              </div>
              <div>
                <h4 className="font-bold text-white">Partager le Lien</h4>
                <p className="text-slate-300 text-sm">Donnez cette URL à vos amis pour qu'ils puissent jouer !</p>
              </div>
            </div>
          </div>
        </div>

        {/* Exemples de Partage */}
        <div className="bg-gradient-to-r from-purple-900/50 to-pink-900/50 rounded-xl p-6 border border-purple-500/30">
          <h3 className="text-xl font-bold text-white mb-4">💬 Comment Partager</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-800/50 rounded-lg p-4">
              <h4 className="font-bold text-white mb-2">📱 Message Simple :</h4>
              <div className="bg-slate-900 rounded p-3 text-sm text-slate-300">
                "Salut ! J'ai créé un casino en ligne, viens tester : <br />
                <span className="text-blue-400">https://votre-casino.vercel.app</span>
                <br />
                Tu peux t'inscrire gratuitement et tu auras 1000 crédits pour commencer ! 🎰"
              </div>
            </div>

            <div className="bg-slate-800/50 rounded-lg p-4">
              <h4 className="font-bold text-white mb-2">🎮 Message Détaillé :</h4>
              <div className="bg-slate-900 rounded p-3 text-sm text-slate-300">
                "🎰 DPC'asino est en ligne !<br />✅ Poker, Blackjack, Roulette, Slots
                <br />✅ Multijoueur en temps réel
                <br />✅ Système de ranking
                <br />✅ Récompenses quotidiennes
                <br />
                <span className="text-blue-400">https://votre-casino.vercel.app</span>"
              </div>
            </div>
          </div>
        </div>

        {/* Sécurité */}
        <div className="bg-blue-900/20 rounded-xl p-6 border border-blue-500/30">
          <h3 className="text-lg font-bold text-white mb-3 flex items-center">
            <Shield className="w-5 h-5 mr-2 text-blue-400" />
            Sécurité et Confidentialité
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-medium text-white mb-2">🔒 Données Sécurisées :</h4>
              <ul className="text-slate-300 space-y-1">
                <li>• Mots de passe hashés</li>
                <li>• Sessions sécurisées</li>
                <li>• HTTPS automatique</li>
                <li>• Pas de données sensibles stockées</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-white mb-2">🎮 Jeu Responsable :</h4>
              <ul className="text-slate-300 space-y-1">
                <li>• Crédits virtuels uniquement</li>
                <li>• Pas d'argent réel</li>
                <li>• Divertissement pur</li>
                <li>• Système anti-triche</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="text-center space-y-4">
          <Button
            size="lg"
            className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-xl px-8 py-4"
            onClick={() => window.open("https://vercel.com/new", "_blank")}
          >
            <Zap className="w-5 h-5 mr-2" />
            Déployer Maintenant
          </Button>

          <div className="text-slate-400 text-sm">
            Une fois déployé, remplacez l'URL d'exemple par votre vraie URL !
          </div>
        </div>
      </div>
    </div>
  )
}
