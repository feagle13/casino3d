"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { User, Mail, Lock, CheckCircle } from "lucide-react"

interface AuthSystemProps {
  onLogin: (user: any) => void
}

export default function AuthSystem({ onLogin }: AuthSystemProps) {
  const [isLogin, setIsLogin] = useState(true)
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
  })
  const [loading, setLoading] = useState(false)
  const [errors, setErrors] = useState<{ [key: string]: string }>({})
  const [showDevAccounts, setShowDevAccounts] = useState(false)

  // Vérifier si on est en mode développement
  const isDevelopment = process.env.NODE_ENV === "development" || window.location.hostname === "localhost"

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setErrors({})

    try {
      // Simulation d'authentification
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Comptes de démonstration (cachés en production)
      const demoAccounts = [
        { email: "demo@example.com", password: "demo123", username: "Demo User" },
        { email: "admin@dpcasino.com", password: "admin123", username: "Admin" },
        { email: "player@test.com", password: "player123", username: "Test Player" },
        { email: "vip@casino.com", password: "vip123", username: "VIP Player" },
        { email: "pro@poker.com", password: "pro123", username: "Poker Pro" },
      ]

      if (isLogin) {
        // Vérifier les comptes de démo
        const account = demoAccounts.find((acc) => acc.email === formData.email && acc.password === formData.password)

        if (account) {
          const user = {
            id: Math.random().toString(36).substr(2, 9),
            username: account.username,
            email: account.email,
            credits: account.username === "VIP Player" ? 5000 : account.username === "Admin" ? 10000 : 1000,
            level: account.username === "VIP Player" ? 5 : account.username === "Admin" ? 10 : 1,
            experience: account.username === "VIP Player" ? 2500 : 0,
            avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${account.username}`,
            verified: true,
            provider: "email",
            stats: {
              gamesPlayed: account.username === "VIP Player" ? 150 : 0,
              gamesWon: account.username === "VIP Player" ? 95 : 0,
              totalWinnings: account.username === "VIP Player" ? 25000 : 0,
              currentStreak: account.username === "VIP Player" ? 8 : 0,
              bestStreak: account.username === "VIP Player" ? 15 : 0,
            },
            dailyRewards: {
              lastClaim:
                account.username === "VIP Player" ? new Date(Date.now() - 25 * 60 * 60 * 1000).toISOString() : null,
              streak: account.username === "VIP Player" ? 12 : 0,
              totalClaimed: account.username === "VIP Player" ? 45 : 0,
            },
          }
          onLogin(user)
        } else {
          setErrors({ general: "Email ou mot de passe incorrect." })
        }
      } else {
        // Inscription - créer un nouveau compte
        if (formData.username.length < 3) {
          setErrors({ general: "Le nom d'utilisateur doit faire au moins 3 caractères." })
          return
        }

        const user = {
          id: Math.random().toString(36).substr(2, 9),
          username: formData.username,
          email: formData.email,
          credits: 1000,
          level: 1,
          experience: 0,
          avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${formData.username}`,
          verified: true,
          provider: "email",
          stats: { gamesPlayed: 0, gamesWon: 0, totalWinnings: 0, currentStreak: 0, bestStreak: 0 },
          dailyRewards: { lastClaim: null, streak: 0, totalClaimed: 0 },
        }
        onLogin(user)
      }
    } catch (error) {
      setErrors({ general: "Erreur de connexion" })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-8">
        {/* Logo */}
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
              <span className="text-black font-bold text-2xl">D</span>
            </div>
            <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
              DPC'asino
            </h1>
          </div>
          <p className="text-slate-300">Casino multijoueur en ligne</p>
        </div>

        {/* Security Notice - Seulement en développement */}
        {isDevelopment && (
          <div className="bg-green-900/20 rounded-xl p-4 border border-green-500/30">
            <div className="flex items-center space-x-2 text-green-300">
              <CheckCircle className="w-5 h-5" />
              <span className="text-sm font-medium">Mode Développement ✓</span>
            </div>
          </div>
        )}

        {/* Auth Form */}
        <div className="bg-slate-800/50 rounded-xl p-8 border border-slate-700">
          <div className="flex space-x-4 mb-6">
            <Button
              variant={isLogin ? "default" : "outline"}
              onClick={() => setIsLogin(true)}
              className={isLogin ? "bg-blue-600 hover:bg-blue-700" : "border-slate-600"}
            >
              Connexion
            </Button>
            <Button
              variant={!isLogin ? "default" : "outline"}
              onClick={() => setIsLogin(false)}
              className={!isLogin ? "bg-blue-600 hover:bg-blue-700" : "border-slate-600"}
            >
              Inscription
            </Button>
          </div>

          {errors.general && (
            <div className="mb-4 p-3 bg-red-900/20 border border-red-500/30 rounded-lg">
              <p className="text-red-400 text-sm">{errors.general}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-300">Nom d'utilisateur</label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none"
                    placeholder="Votre nom d'utilisateur"
                    required
                    minLength={3}
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none"
                  placeholder="votre@email.com"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Mot de passe</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none"
                  placeholder="••••••••"
                  required
                  minLength={6}
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-3"
            >
              {loading ? (
                <div className="flex items-center space-x-2">
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                  <span>{isLogin ? "Connexion..." : "Inscription..."}</span>
                </div>
              ) : isLogin ? (
                "Se connecter"
              ) : (
                "S'inscrire"
              )}
            </Button>
          </form>

          {/* Demo Accounts - Seulement en développement ou si activé */}
          {(isDevelopment || showDevAccounts) && (
            <div className="mt-6 pt-6 border-t border-slate-600">
              <div className="flex justify-between items-center mb-3">
                <h4 className="text-sm font-medium text-slate-300">Comptes de test :</h4>
                {!isDevelopment && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowDevAccounts(false)}
                    className="text-xs border-slate-600"
                  >
                    Masquer
                  </Button>
                )}
              </div>
              <div className="grid grid-cols-1 gap-2 text-xs">
                <div className="bg-slate-700/50 rounded p-2">
                  <div className="text-white font-medium">👤 Demo User</div>
                  <div className="text-slate-400">demo@example.com / demo123</div>
                </div>
                <div className="bg-slate-700/50 rounded p-2">
                  <div className="text-white font-medium">👑 VIP Player</div>
                  <div className="text-slate-400">vip@casino.com / vip123</div>
                </div>
                <div className="bg-slate-700/50 rounded p-2">
                  <div className="text-white font-medium">🎯 Poker Pro</div>
                  <div className="text-slate-400">pro@poker.com / pro123</div>
                </div>
                <div className="bg-slate-700/50 rounded p-2">
                  <div className="text-white font-medium">⚡ Admin</div>
                  <div className="text-slate-400">admin@dpcasino.com / admin123</div>
                </div>
              </div>
            </div>
          )}

          {/* Bouton pour afficher les comptes de test en production */}
          {!isDevelopment && !showDevAccounts && (
            <div className="mt-6 pt-6 border-t border-slate-600 text-center">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setShowDevAccounts(true)}
                className="text-xs border-slate-600 text-slate-400"
              >
                Comptes de démonstration
              </Button>
            </div>
          )}
        </div>

        {/* Demo Mode - Seulement en développement */}
        {isDevelopment && (
          <div className="text-center">
            <Button
              onClick={() =>
                onLogin({
                  id: "demo",
                  username: "Joueur Demo",
                  email: "demo@example.com",
                  credits: 1000,
                  level: 1,
                  experience: 0,
                  avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=demo",
                  verified: true,
                  stats: { gamesPlayed: 0, gamesWon: 0, totalWinnings: 0, currentStreak: 0, bestStreak: 0 },
                  dailyRewards: { lastClaim: null, streak: 0, totalClaimed: 0 },
                })
              }
              variant="outline"
              className="border-slate-600 text-slate-300"
            >
              🎮 Accès Rapide (sans connexion)
            </Button>
          </div>
        )}

        {/* Instructions pour les nouveaux utilisateurs */}
        {!isDevelopment && (
          <div className="bg-blue-900/20 rounded-xl p-4 border border-blue-500/30">
            <div className="text-center text-sm text-blue-300">
              <p className="mb-2">
                🎰 <strong>Nouveau sur DPC'asino ?</strong>
              </p>
              <p>Créez votre compte gratuitement et recevez 1000 crédits de bienvenue !</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
