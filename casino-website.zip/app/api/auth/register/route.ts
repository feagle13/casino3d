import { type NextRequest, NextResponse } from "next/server"
import bcrypt from "bcryptjs"
import { prisma } from "@/lib/prisma"
import { SecurityUtils } from "@/lib/security-utils"
import { sendVerificationEmail } from "@/lib/email"

export async function POST(request: NextRequest) {
  try {
    const { username, email, password } = await request.json()

    // Rate limiting
    const ip = request.ip || request.headers.get("x-forwarded-for") || "unknown"
    if (!SecurityUtils.checkRateLimit(`register:${ip}`, 3, 3600000)) {
      // 3 tentatives par heure
      return NextResponse.json({ error: "Trop de tentatives d'inscription. Réessayez dans 1 heure." }, { status: 429 })
    }

    // Validation
    const emailValidation = SecurityUtils.validateEmail(email)
    if (!emailValidation.isValid) {
      return NextResponse.json({ error: emailValidation.error }, { status: 400 })
    }

    const usernameValidation = SecurityUtils.validateUsername(username)
    if (!usernameValidation.isValid) {
      return NextResponse.json({ error: usernameValidation.error }, { status: 400 })
    }

    const passwordValidation = SecurityUtils.validatePassword(password)
    if (!passwordValidation.isValid) {
      return NextResponse.json({ error: passwordValidation.errors.join(", ") }, { status: 400 })
    }

    // Vérifier si l'utilisateur existe déjà
    const existingUser = await prisma.user.findFirst({
      where: {
        OR: [{ email }, { username }],
      },
    })

    if (existingUser) {
      return NextResponse.json({ error: "Un compte avec cet email ou nom d'utilisateur existe déjà" }, { status: 400 })
    }

    // Hasher le mot de passe
    const hashedPassword = await bcrypt.hash(password, 12)

    // Créer l'utilisateur
    const user = await prisma.user.create({
      data: {
        username: SecurityUtils.sanitizeInput(username),
        email: email.toLowerCase(),
        password: hashedPassword,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
      },
    })

    // Créer les stats et récompenses
    await Promise.all([
      prisma.userStats.create({
        data: { userId: user.id },
      }),
      prisma.dailyRewards.create({
        data: { userId: user.id },
      }),
    ])

    // Générer token de vérification
    const verificationToken = SecurityUtils.generateSecureToken()
    await prisma.verificationToken.create({
      data: {
        identifier: email,
        token: verificationToken,
        expires: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24h
      },
    })

    // Envoyer email de vérification
    await sendVerificationEmail(email, verificationToken)

    // Log de sécurité
    await prisma.securityLog.create({
      data: {
        userId: user.id,
        action: "REGISTER",
        ip,
        userAgent: request.headers.get("user-agent"),
        details: { email, username },
      },
    })

    return NextResponse.json({
      message: "Compte créé avec succès. Vérifiez votre email pour l'activer.",
      userId: user.id,
    })
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json({ error: "Erreur interne du serveur" }, { status: 500 })
  }
}
