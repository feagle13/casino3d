// Utilitaires de sécurité

export class SecurityUtils {
  // Validation d'email avancée
  static validateEmail(email: string): { isValid: boolean; error?: string } {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/

    if (!emailRegex.test(email)) {
      return { isValid: false, error: "Format d'email invalide" }
    }

    // Liste des domaines d'emails temporaires à bloquer
    const disposableDomains = [
      "10minutemail.com",
      "tempmail.org",
      "guerrillamail.com",
      "mailinator.com",
      "throwaway.email",
      "temp-mail.org",
      "yopmail.com",
      "maildrop.cc",
      "sharklasers.com",
    ]

    const domain = email.split("@")[1]?.toLowerCase()
    if (disposableDomains.includes(domain)) {
      return { isValid: false, error: "Les emails temporaires ne sont pas autorisés" }
    }

    return { isValid: true }
  }

  // Validation de mot de passe sécurisé
  static validatePassword(password: string): { isValid: boolean; errors: string[] } {
    const errors: string[] = []

    if (password.length < 8) {
      errors.push("Minimum 8 caractères")
    }

    if (!/[A-Z]/.test(password)) {
      errors.push("Au moins une majuscule")
    }

    if (!/[a-z]/.test(password)) {
      errors.push("Au moins une minuscule")
    }

    if (!/\d/.test(password)) {
      errors.push("Au moins un chiffre")
    }

    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
      errors.push("Au moins un caractère spécial")
    }

    // Vérifier les mots de passe communs
    const commonPasswords = [
      "password",
      "123456",
      "password123",
      "admin",
      "qwerty",
      "letmein",
      "welcome",
      "monkey",
      "dragon",
    ]

    if (commonPasswords.includes(password.toLowerCase())) {
      errors.push("Mot de passe trop commun")
    }

    return { isValid: errors.length === 0, errors }
  }

  // Rate limiting simple (en production, utiliser Redis)
  static rateLimiter = new Map<string, { count: number; resetTime: number }>()

  static checkRateLimit(identifier: string, maxAttempts = 5, windowMs = 300000): boolean {
    const now = Date.now()
    const record = this.rateLimiter.get(identifier)

    if (!record || now > record.resetTime) {
      this.rateLimiter.set(identifier, { count: 1, resetTime: now + windowMs })
      return true
    }

    if (record.count >= maxAttempts) {
      return false
    }

    record.count++
    return true
  }

  // Sanitisation des entrées
  static sanitizeInput(input: string): string {
    return input
      .trim()
      .replace(/[<>]/g, "") // Enlever les balises HTML basiques
      .substring(0, 1000) // Limiter la longueur
  }

  // Validation du nom d'utilisateur
  static validateUsername(username: string): { isValid: boolean; error?: string } {
    const sanitized = this.sanitizeInput(username)

    if (sanitized.length < 3 || sanitized.length > 20) {
      return { isValid: false, error: "Le nom d'utilisateur doit faire entre 3 et 20 caractères" }
    }

    if (!/^[a-zA-Z0-9_-]+$/.test(sanitized)) {
      return { isValid: false, error: "Seuls les lettres, chiffres, _ et - sont autorisés" }
    }

    const forbiddenWords = [
      "admin",
      "root",
      "test",
      "bot",
      "casino",
      "support",
      "moderator",
      "null",
      "undefined",
      "system",
    ]

    if (forbiddenWords.some((word) => sanitized.toLowerCase().includes(word))) {
      return { isValid: false, error: "Ce nom d'utilisateur contient des mots interdits" }
    }

    return { isValid: true }
  }

  // Génération de token sécurisé
  static generateSecureToken(length = 32): string {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    let result = ""
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return result
  }

  // Vérification de l'intégrité des données
  static verifyDataIntegrity(data: any): boolean {
    // Vérifier que les données ne contiennent pas de scripts malveillants
    const dataString = JSON.stringify(data)
    const maliciousPatterns = [/<script/i, /javascript:/i, /on\w+=/i, /eval\(/i, /function\(/i]

    return !maliciousPatterns.some((pattern) => pattern.test(dataString))
  }
}
