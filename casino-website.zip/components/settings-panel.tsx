"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Volume2, VolumeX, Monitor, Moon, Sun, Gamepad2, User, Shield } from "lucide-react"

interface SettingsPanelProps {
  onClose: () => void
}

export default function SettingsPanel({ onClose }: SettingsPanelProps) {
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [theme, setTheme] = useState<"dark" | "light" | "auto">("dark")
  const [animations, setAnimations] = useState(true)
  const [notifications, setNotifications] = useState(true)
  const [autoPlay, setAutoPlay] = useState(false)
  const [difficulty, setDifficulty] = useState<"easy" | "medium" | "hard">("medium")

  const playSound = () => {
    if (!soundEnabled) return
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    const oscillator = audioContext.createOscillator()
    const gainNode = audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(audioContext.destination)

    oscillator.frequency.setValueAtTime(440, audioContext.currentTime)
    oscillator.type = "sine"

    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime)
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2)

    oscillator.start(audioContext.currentTime)
    oscillator.stop(audioContext.currentTime + 0.2)
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white">Paramètres</h2>
        <Button onClick={onClose} variant="outline" className="border-slate-600 text-slate-300">
          Fermer
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Audio Settings */}
        <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center">
            <Volume2 className="w-5 h-5 mr-2" />
            Audio
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-slate-300">Effets sonores</span>
              <Button
                variant={soundEnabled ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  setSoundEnabled(!soundEnabled)
                  playSound()
                }}
                className={soundEnabled ? "bg-green-600 hover:bg-green-700" : ""}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </Button>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-300">Volume principal</span>
              <input type="range" min="0" max="100" defaultValue="70" className="w-24" disabled={!soundEnabled} />
            </div>
          </div>
        </div>

        {/* Display Settings */}
        <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center">
            <Monitor className="w-5 h-5 mr-2" />
            Affichage
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-slate-300">Thème</span>
              <div className="flex space-x-1">
                {[
                  { value: "dark", icon: Moon },
                  { value: "light", icon: Sun },
                  { value: "auto", icon: Monitor },
                ].map(({ value, icon: Icon }) => (
                  <Button
                    key={value}
                    variant={theme === value ? "default" : "outline"}
                    size="sm"
                    onClick={() => setTheme(value as any)}
                    className={theme === value ? "bg-blue-600 hover:bg-blue-700" : ""}
                  >
                    <Icon className="w-4 h-4" />
                  </Button>
                ))}
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-300">Animations</span>
              <Button
                variant={animations ? "default" : "outline"}
                size="sm"
                onClick={() => setAnimations(!animations)}
                className={animations ? "bg-green-600 hover:bg-green-700" : ""}
              >
                {animations ? "Activées" : "Désactivées"}
              </Button>
            </div>
          </div>
        </div>

        {/* Game Settings */}
        <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center">
            <Gamepad2 className="w-5 h-5 mr-2" />
            Jeu
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-slate-300">Difficulté IA</span>
              <div className="flex space-x-1">
                {[
                  { value: "easy", label: "Facile", color: "bg-green-600" },
                  { value: "medium", label: "Moyen", color: "bg-yellow-600" },
                  { value: "hard", label: "Difficile", color: "bg-red-600" },
                ].map(({ value, label, color }) => (
                  <Button
                    key={value}
                    variant={difficulty === value ? "default" : "outline"}
                    size="sm"
                    onClick={() => setDifficulty(value as any)}
                    className={difficulty === value ? `${color} hover:opacity-80` : ""}
                  >
                    {label}
                  </Button>
                ))}
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-300">Jeu automatique</span>
              <Button
                variant={autoPlay ? "default" : "outline"}
                size="sm"
                onClick={() => setAutoPlay(!autoPlay)}
                className={autoPlay ? "bg-purple-600 hover:bg-purple-700" : ""}
              >
                {autoPlay ? "Activé" : "Désactivé"}
              </Button>
            </div>
          </div>
        </div>

        {/* Account Settings */}
        <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center">
            <User className="w-5 h-5 mr-2" />
            Compte
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-slate-300">Notifications</span>
              <Button
                variant={notifications ? "default" : "outline"}
                size="sm"
                onClick={() => setNotifications(!notifications)}
                className={notifications ? "bg-blue-600 hover:bg-blue-700" : ""}
              >
                {notifications ? "Activées" : "Désactivées"}
              </Button>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-300">Statut</span>
              <Badge className="bg-green-600">En ligne</Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Advanced Settings */}
      <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center">
          <Shield className="w-5 h-5 mr-2" />
          Paramètres avancés
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button variant="outline" className="border-slate-600 text-slate-300">
            Réinitialiser les statistiques
          </Button>
          <Button variant="outline" className="border-slate-600 text-slate-300">
            Exporter les données
          </Button>
          <Button variant="outline" className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white">
            Supprimer le compte
          </Button>
        </div>
      </div>

      {/* Save Button */}
      <div className="text-center">
        <Button
          onClick={() => {
            playSound()
            onClose()
          }}
          className="bg-green-600 hover:bg-green-700 px-8 py-3"
        >
          Sauvegarder les paramètres
        </Button>
      </div>
    </div>
  )
}
