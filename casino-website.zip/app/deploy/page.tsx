import DeploymentGuide from "@/components/deployment-guide"

export default function DeployPage() {
  return <DeploymentGuide />
}
