import SetupGuide from "@/components/setup-guide"

export default function SetupPage() {
  return <SetupGuide />
}
