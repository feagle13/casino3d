import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Providers } from "./providers"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "DPC'asino - Casino Multijoueur Sécurisé",
  description: "Le casino en ligne le plus sécurisé avec système de ranking compétitif et multijoueur en temps réel",
  keywords: "casino, poker, blackjack, roulette, multijoueur, sécurisé",
  authors: [{ name: "DPC'asino Team" }],
  openGraph: {
    title: "DPC'asino - Casino Multijoueur",
    description: "Casino en ligne sécurisé avec jeux multijoueur",
    type: "website",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr">
      <body className={inter.className}>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
