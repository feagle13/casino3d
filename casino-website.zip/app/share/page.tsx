import PublicDeploymentInfo from "@/components/public-deployment-info"

export default function SharePage() {
  return <PublicDeploymentInfo />
}
