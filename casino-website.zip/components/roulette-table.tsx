"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface RouletteTableProps {
  credits: number
  setCredits: (credits: number) => void
  playerRank?: string
  onGameEnd?: (won: boolean, lpChange: number) => void
}

export default function RouletteTable({ credits, setCredits, playerRank, onGameEnd }: RouletteTableProps) {
  const [bets, setBets] = useState<{ [key: string]: number }>({})
  const [spinning, setSpinning] = useState(false)
  const [result, setResult] = useState<number | null>(null)
  const [message, setMessage] = useState("Placez vos mises")
  const [selectedChip, setSelectedChip] = useState(5)
  const [wheelRotation, setWheelRotation] = useState(0)
  const [ballRotation, setBallRotation] = useState(0)
  const [recentNumbers, setRecentNumbers] = useState<number[]>([])

  const rouletteNumbers = [
    0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29,
    7, 28, 12, 35, 3, 26,
  ]

  const redNumbers = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]
  const chipValues = [1, 5, 10, 25, 50, 100]

  const getNumberColor = (num: number) => {
    if (num === 0) return "green"
    return redNumbers.includes(num) ? "red" : "black"
  }

  const playSound = (type: string) => {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    let frequency = 440

    switch (type) {
      case "chip":
        frequency = 800
        break
      case "spin":
        frequency = 200
        break
      case "win":
        frequency = 600
        break
      case "lose":
        frequency = 150
        break
    }

    const oscillator = audioContext.createOscillator()
    const gainNode = audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(audioContext.destination)

    oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime)
    oscillator.type = "sine"

    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime)
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2)

    oscillator.start(audioContext.currentTime)
    oscillator.stop(audioContext.currentTime + 0.2)
  }

  const placeBet = (betType: string) => {
    if (selectedChip > credits) {
      setMessage("Pas assez de crédits!")
      return
    }

    setBets((prev) => ({
      ...prev,
      [betType]: (prev[betType] || 0) + selectedChip,
    }))
    setCredits(credits - selectedChip)
    setMessage("Mise placée!")
    playSound("chip")
  }

  const spin = () => {
    if (Object.keys(bets).length === 0) {
      setMessage("Placez au moins une mise!")
      return
    }

    setSpinning(true)
    setMessage("Rien ne va plus!")
    playSound("spin")

    // Animation améliorée de la roue et de la bille
    const spins = 8 + Math.random() * 4 // 8-12 tours
    const finalWheelRotation = wheelRotation + spins * 360
    const finalBallRotation = ballRotation - (spins + 2) * 360 // Sens inverse, plus de tours

    setWheelRotation(finalWheelRotation)
    setBallRotation(finalBallRotation)

    setTimeout(() => {
      const winningNumber = rouletteNumbers[Math.floor(Math.random() * rouletteNumbers.length)]
      setResult(winningNumber)
      setRecentNumbers((prev) => [winningNumber, ...prev.slice(0, 9)])
      setSpinning(false)

      let totalWin = 0
      const winningColor = getNumberColor(winningNumber)

      // Vérifier les mises gagnantes
      Object.entries(bets).forEach(([betType, amount]) => {
        let win = false
        let multiplier = 0

        // Numéro plein
        if (betType === `number-${winningNumber}`) {
          win = true
          multiplier = 35
        }
        // Couleur
        else if (betType === winningColor && winningNumber !== 0) {
          win = true
          multiplier = 1
        }
        // Pair/Impair
        else if (betType === "even" && winningNumber % 2 === 0 && winningNumber !== 0) {
          win = true
          multiplier = 1
        } else if (betType === "odd" && winningNumber % 2 === 1) {
          win = true
          multiplier = 1
        }
        // Manque/Passe
        else if (betType === "low" && winningNumber >= 1 && winningNumber <= 18) {
          win = true
          multiplier = 1
        } else if (betType === "high" && winningNumber >= 19 && winningNumber <= 36) {
          win = true
          multiplier = 1
        }
        // Douzaines
        else if (betType === "dozen1" && winningNumber >= 1 && winningNumber <= 12) {
          win = true
          multiplier = 2
        } else if (betType === "dozen2" && winningNumber >= 13 && winningNumber <= 24) {
          win = true
          multiplier = 2
        } else if (betType === "dozen3" && winningNumber >= 25 && winningNumber <= 36) {
          win = true
          multiplier = 2
        }
        // Colonnes
        else if (betType === "column1" && winningNumber % 3 === 1 && winningNumber !== 0) {
          win = true
          multiplier = 2
        } else if (betType === "column2" && winningNumber % 3 === 2 && winningNumber !== 0) {
          win = true
          multiplier = 2
        } else if (betType === "column3" && winningNumber % 3 === 0 && winningNumber !== 0) {
          win = true
          multiplier = 2
        }

        if (win) {
          totalWin += amount * (multiplier + 1)
        }
      })

      if (totalWin > 0) {
        setCredits((prev) => prev + totalWin)
        setMessage(`🎉 ${winningNumber} ${winningColor}! Vous gagnez ${totalWin} crédits!`)
        playSound("win")
        if (onGameEnd) onGameEnd(true, 15)
      } else {
        setMessage(`${winningNumber} ${winningColor}. Vous perdez.`)
        playSound("lose")
        if (onGameEnd) onGameEnd(false, -10)
      }

      setBets({})
    }, 5000) // Animation plus longue
  }

  const clearBets = () => {
    const totalBets = Object.values(bets).reduce((sum, bet) => sum + bet, 0)
    setCredits(credits + totalBets)
    setBets({})
    setMessage("Mises annulées")
  }

  return (
    <div className="text-white space-y-6">
      {/* Game Info */}
      <div className="flex justify-between items-center">
        <div className="flex space-x-4">
          <Badge variant="outline" className="border-yellow-400 text-yellow-400">
            Crédits: {credits}
          </Badge>
          <Badge variant="outline" className="border-blue-400 text-blue-400">
            Total misé: {Object.values(bets).reduce((sum, bet) => sum + bet, 0)}
          </Badge>
        </div>
        <div className="text-xl font-bold">{message}</div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Roulette Wheel */}
        <div className="xl:col-span-1 flex flex-col items-center space-y-4">
          <div className="relative">
            {/* Roulette Wheel avec animation améliorée */}
            <div className="relative w-80 h-80">
              {/* Outer rim */}
              <div className="absolute inset-0 rounded-full border-8 border-yellow-600 bg-gradient-to-r from-yellow-700 to-yellow-500 shadow-2xl"></div>

              {/* Wheel */}
              <div
                className="absolute inset-6 rounded-full bg-gradient-conic from-red-800 via-black via-red-800 via-black to-red-800 shadow-inner"
                style={{
                  transform: `rotate(${wheelRotation}deg)`,
                  transition: spinning ? "transform 5s cubic-bezier(0.25, 0.1, 0.25, 1)" : "none",
                }}
              >
                {/* Numbers on wheel */}
                {rouletteNumbers.map((num, index) => {
                  const angle = (index * 360) / rouletteNumbers.length
                  const color = getNumberColor(num)
                  return (
                    <div
                      key={num}
                      className={`absolute w-6 h-6 flex items-center justify-center text-xs font-bold rounded ${
                        color === "red"
                          ? "bg-red-600 text-white"
                          : color === "black"
                            ? "bg-black text-white border border-white"
                            : "bg-green-600 text-white"
                      }`}
                      style={{
                        transform: `rotate(${angle}deg) translateY(-130px) rotate(-${angle}deg)`,
                        transformOrigin: "center 130px",
                        left: "50%",
                        top: "50%",
                        marginLeft: "-12px",
                        marginTop: "-12px",
                      }}
                    >
                      {num}
                    </div>
                  )
                })}

                {/* Center */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center shadow-lg">
                    <div className="w-8 h-8 bg-black rounded-full"></div>
                  </div>
                </div>
              </div>

              {/* Ball track */}
              <div className="absolute inset-4 rounded-full border-4 border-yellow-400 shadow-inner"></div>

              {/* Ball avec animation améliorée */}
              <div
                className="absolute w-4 h-4 bg-white rounded-full shadow-lg z-10 border-2 border-gray-300"
                style={{
                  transform: `rotate(${ballRotation}deg) translateY(-140px)`,
                  transformOrigin: "center 140px",
                  left: "50%",
                  top: "50%",
                  marginLeft: "-8px",
                  marginTop: "-8px",
                  transition: spinning ? "transform 5s cubic-bezier(0.25, 0.1, 0.25, 1)" : "none",
                }}
              ></div>

              {/* Pointer */}
              <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-b-8 border-l-transparent border-r-transparent border-b-yellow-400 z-20"></div>
            </div>

            {/* Result Display */}
            {result !== null && (
              <div className="mt-4 text-center">
                <div
                  className={`inline-block px-8 py-4 rounded-lg text-4xl font-bold shadow-lg ${
                    getNumberColor(result) === "red"
                      ? "bg-red-600"
                      : getNumberColor(result) === "black"
                        ? "bg-black"
                        : "bg-green-600"
                  }`}
                >
                  {result}
                </div>
              </div>
            )}
          </div>

          {/* Recent Numbers */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-center">Derniers numéros</h3>
            <div className="flex space-x-1">
              {recentNumbers.slice(0, 10).map((num, index) => (
                <div
                  key={index}
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                    getNumberColor(num) === "red"
                      ? "bg-red-600"
                      : getNumberColor(num) === "black"
                        ? "bg-black"
                        : "bg-green-600"
                  }`}
                >
                  {num}
                </div>
              ))}
            </div>
          </div>

          {/* Chip Selection */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-center">Jetons</h3>
            <div className="grid grid-cols-3 gap-2">
              {chipValues.map((value) => (
                <button
                  key={value}
                  onClick={() => setSelectedChip(value)}
                  disabled={value > credits}
                  className={`w-14 h-14 rounded-full border-4 font-bold text-xs transition-all ${
                    selectedChip === value ? "border-yellow-400 scale-110" : "border-gray-400 hover:border-yellow-200"
                  } ${
                    value <= 5
                      ? "bg-red-600"
                      : value <= 25
                        ? "bg-blue-600"
                        : value <= 50
                          ? "bg-green-600"
                          : "bg-purple-600"
                  } ${value > credits ? "opacity-50 cursor-not-allowed" : "cursor-pointer hover:scale-105"}`}
                >
                  {value}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Betting Table avec grille de petits carrés */}
        <div className="xl:col-span-2 space-y-4">
          <div className="bg-green-800 p-6 rounded-lg">
            {/* Main betting grid - Grille de petits carrés */}
            <div className="space-y-2">
              {/* Zero */}
              <div className="flex justify-center mb-4">
                <button
                  onClick={() => placeBet("number-0")}
                  disabled={spinning}
                  className="w-12 h-12 bg-green-600 hover:bg-green-500 text-white font-bold rounded relative text-sm"
                >
                  0
                  {bets["number-0"] && (
                    <div className="absolute -top-1 -right-1 bg-yellow-400 text-black text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      {bets["number-0"]}
                    </div>
                  )}
                </button>
              </div>

              {/* Numbers 1-36 en grille de petits carrés */}
              {[
                [3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36],
                [2, 5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35],
                [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34],
              ].map((row, rowIndex) => (
                <div key={rowIndex} className="flex space-x-1 justify-center">
                  {row.map((num) => {
                    const color = getNumberColor(num)
                    return (
                      <button
                        key={num}
                        onClick={() => placeBet(`number-${num}`)}
                        disabled={spinning}
                        className={`w-12 h-12 ${
                          color === "red" ? "bg-red-600 hover:bg-red-500" : "bg-black hover:bg-gray-800"
                        } text-white font-bold rounded relative transition-colors text-sm`}
                      >
                        {num}
                        {bets[`number-${num}`] && (
                          <div className="absolute -top-1 -right-1 bg-yellow-400 text-black text-xs rounded-full w-5 h-5 flex items-center justify-center">
                            {bets[`number-${num}`]}
                          </div>
                        )}
                      </button>
                    )
                  })}
                  {/* Column bet */}
                  <button
                    onClick={() => placeBet(`column${rowIndex + 1}`)}
                    disabled={spinning}
                    className="w-12 h-12 bg-gray-700 hover:bg-gray-600 text-white font-bold rounded relative text-xs ml-2"
                  >
                    2:1
                    {bets[`column${rowIndex + 1}`] && (
                      <div className="absolute -top-1 -right-1 bg-yellow-400 text-black text-xs rounded-full w-5 h-5 flex items-center justify-center">
                        {bets[`column${rowIndex + 1}`]}
                      </div>
                    )}
                  </button>
                </div>
              ))}

              {/* Dozen bets */}
              <div className="flex space-x-1 justify-center mt-4">
                {[
                  { key: "dozen1", label: "1-12" },
                  { key: "dozen2", label: "13-24" },
                  { key: "dozen3", label: "25-36" },
                ].map(({ key, label }) => (
                  <button
                    key={key}
                    onClick={() => placeBet(key)}
                    disabled={spinning}
                    className="w-32 h-12 bg-gray-700 hover:bg-gray-600 text-white font-bold rounded relative text-sm"
                  >
                    {label}
                    {bets[key] && (
                      <div className="absolute -top-1 -right-1 bg-yellow-400 text-black text-xs rounded-full w-5 h-5 flex items-center justify-center">
                        {bets[key]}
                      </div>
                    )}
                  </button>
                ))}
              </div>

              {/* Outside bets */}
              <div className="flex space-x-1 justify-center mt-4">
                {[
                  { key: "low", label: "1-18", color: "bg-gray-700" },
                  { key: "even", label: "PAIR", color: "bg-gray-700" },
                  { key: "red", label: "ROUGE", color: "bg-red-600" },
                  { key: "black", label: "NOIR", color: "bg-black" },
                  { key: "odd", label: "IMPAIR", color: "bg-gray-700" },
                  { key: "high", label: "19-36", color: "bg-gray-700" },
                ].map(({ key, label, color }) => (
                  <button
                    key={key}
                    onClick={() => placeBet(key)}
                    disabled={spinning}
                    className={`w-20 h-12 ${color} hover:opacity-80 text-white font-bold rounded relative text-xs`}
                  >
                    {label}
                    {bets[key] && (
                      <div className="absolute -top-1 -right-1 bg-yellow-400 text-black text-xs rounded-full w-5 h-5 flex items-center justify-center">
                        {bets[key]}
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex space-x-4 justify-center">
            <Button
              onClick={spin}
              disabled={spinning || Object.keys(bets).length === 0}
              className="bg-green-600 hover:bg-green-700 text-xl px-8 py-4"
            >
              {spinning ? "🎯 En cours..." : "🎯 Lancer"}
            </Button>
            <Button
              onClick={clearBets}
              disabled={spinning || Object.keys(bets).length === 0}
              variant="outline"
              className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
            >
              Annuler mises
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
