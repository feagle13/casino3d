"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Copy, Check, Globe, Zap } from "lucide-react"

export default function DeploymentGuide() {
  const [copiedCommand, setCopiedCommand] = useState("")

  const copyToClipboard = async (text: string, commandType: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedCommand(commandType)
      setTimeout(() => setCopiedCommand(""), 2000)
    } catch (err) {
      console.error("Erreur de copie:", err)
    }
  }

  const deploymentOptions = [
    {
      name: "Vercel",
      description: "Déploiement gratuit et instantané",
      icon: "▲",
      color: "from-black to-gray-800",
      steps: [
        "Créer un compte sur vercel.com",
        "Connecter votre repository GitHub",
        "Déployer automatiquement",
        "Votre casino sera en ligne en 2 minutes!",
      ],
      command: "npx vercel --prod",
      pros: ["Gratuit", "Très rapide", "SSL automatique", "CDN mondial"],
      url: "https://vercel.com",
    },
    {
      name: "Netlify",
      description: "Alternative gratuite populaire",
      icon: "🌐",
      color: "from-teal-600 to-cyan-600",
      steps: [
        "Créer un compte sur netlify.com",
        "Glisser-déposer votre dossier build",
        "Ou connecter GitHub",
        "Site en ligne instantanément!",
      ],
      command: "npm run build && npx netlify deploy --prod --dir=out",
      pros: ["Gratuit", "Drag & drop", "Formulaires", "Analytics"],
      url: "https://netlify.com",
    },
    {
      name: "Railway",
      description: "Hébergement moderne avec base de données",
      icon: "🚂",
      color: "from-purple-600 to-pink-600",
      steps: [
        "Créer un compte sur railway.app",
        "Connecter GitHub",
        "Ajouter variables d'environnement",
        "Déploiement automatique!",
      ],
      command: "railway login && railway deploy",
      pros: ["Base de données incluse", "Scaling automatique", "Logs en temps réel"],
      url: "https://railway.app",
    },
    {
      name: "Render",
      description: "Hébergement gratuit avec SSL",
      icon: "🎨",
      color: "from-blue-600 to-indigo-600",
      steps: [
        "Créer un compte sur render.com",
        "Connecter votre repository",
        "Configurer les variables",
        "Déploiement automatique!",
      ],
      command: "git push origin main",
      pros: ["Gratuit", "SSL automatique", "Base de données PostgreSQL"],
      url: "https://render.com",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
              <span className="text-black font-bold text-2xl">D</span>
            </div>
            <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
              DPC'asino
            </h1>
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">Déploiement Simplifié</h2>
          <p className="text-slate-300">Mettez votre casino en ligne en quelques minutes</p>
        </div>

        {/* Current Status */}
        <div className="bg-green-900/20 rounded-xl p-6 border border-green-500/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center">
                <Check className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Casino Prêt au Déploiement</h3>
                <p className="text-green-300">✓ Authentification simplifiée (sans Google)</p>
                <p className="text-green-300">✓ Tous les jeux fonctionnels</p>
                <p className="text-green-300">✓ Configuration optimisée</p>
              </div>
            </div>
            <Badge className="bg-green-600 text-white">
              <Zap className="w-4 h-4 mr-1" />
              Prêt à déployer
            </Badge>
          </div>
        </div>

        {/* Deployment Options */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {deploymentOptions.map((option, index) => (
            <div key={option.name} className="bg-slate-800/50 rounded-xl border border-slate-700 overflow-hidden">
              {/* Header */}
              <div className={`bg-gradient-to-r ${option.color} p-6`}>
                <div className="flex items-center space-x-3">
                  <div className="text-3xl">{option.icon}</div>
                  <div>
                    <h3 className="text-2xl font-bold text-white">{option.name}</h3>
                    <p className="text-white/80">{option.description}</p>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-4">
                {/* Steps */}
                <div>
                  <h4 className="font-bold text-white mb-3">Étapes :</h4>
                  <div className="space-y-2">
                    {option.steps.map((step, stepIndex) => (
                      <div key={stepIndex} className="flex items-start space-x-3">
                        <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold mt-0.5">
                          {stepIndex + 1}
                        </div>
                        <span className="text-slate-300 text-sm">{step}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Command */}
                <div>
                  <h4 className="font-bold text-white mb-2">Commande :</h4>
                  <div className="bg-slate-900 rounded-lg p-3 flex justify-between items-center">
                    <code className="text-green-400 text-sm">{option.command}</code>
                    <Button
                      size="sm"
                      onClick={() => copyToClipboard(option.command, option.name)}
                      className="ml-2 bg-blue-600 hover:bg-blue-700"
                    >
                      {copiedCommand === option.name ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                {/* Pros */}
                <div>
                  <h4 className="font-bold text-white mb-2">Avantages :</h4>
                  <div className="flex flex-wrap gap-2">
                    {option.pros.map((pro, proIndex) => (
                      <Badge key={proIndex} variant="outline" className="border-green-400 text-green-400">
                        {pro}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Action */}
                <Button
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  onClick={() => window.open(option.url, "_blank")}
                >
                  <Globe className="w-4 h-4 mr-2" />
                  Aller sur {option.name}
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Deploy Section */}
        <div className="bg-gradient-to-r from-purple-900/50 to-blue-900/50 rounded-xl p-8 border border-purple-500/30">
          <h3 className="text-2xl font-bold text-white mb-6 text-center">🚀 Déploiement Express avec Vercel</h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">1️⃣</span>
              </div>
              <h4 className="font-bold text-white mb-2">Préparer</h4>
              <p className="text-slate-300 text-sm">Votre casino est déjà prêt!</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">2️⃣</span>
              </div>
              <h4 className="font-bold text-white mb-2">Uploader</h4>
              <p className="text-slate-300 text-sm">Glissez votre dossier sur Vercel</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">3️⃣</span>
              </div>
              <h4 className="font-bold text-white mb-2">En ligne!</h4>
              <p className="text-slate-300 text-sm">Votre casino est accessible au monde entier</p>
            </div>
          </div>

          <div className="text-center mt-8">
            <Button
              size="lg"
              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-xl px-8 py-4"
              onClick={() => window.open("https://vercel.com/new", "_blank")}
            >
              <Zap className="w-5 h-5 mr-2" />
              Déployer Maintenant (Gratuit)
            </Button>
          </div>
        </div>

        {/* No Google Notice */}
        <div className="bg-blue-900/20 rounded-xl p-6 border border-blue-500/30">
          <div className="text-center">
            <h4 className="text-lg font-bold text-white mb-3">✅ Configuration Simplifiée</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="bg-slate-800/50 rounded-lg p-4">
                <div className="text-green-400 font-bold mb-2">❌ Plus de Google OAuth</div>
                <p className="text-slate-300">Authentification simplifiée avec comptes de démo</p>
              </div>
              <div className="bg-slate-800/50 rounded-lg p-4">
                <div className="text-green-400 font-bold mb-2">🎮 Comptes de Test</div>
                <p className="text-slate-300">5 comptes prêts à l'emploi pour tester</p>
              </div>
              <div className="bg-slate-800/50 rounded-lg p-4">
                <div className="text-green-400 font-bold mb-2">🚀 Déploiement Facile</div>
                <p className="text-slate-300">Aucune configuration complexe requise</p>
              </div>
            </div>
          </div>
        </div>

        {/* Build Commands */}
        <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
          <h3 className="text-xl font-bold text-white mb-4">📦 Commandes de Build</h3>
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-white mb-2">Pour build local :</h4>
              <div className="bg-slate-900 rounded-lg p-3 flex justify-between items-center">
                <code className="text-green-400">npm run build</code>
                <Button
                  size="sm"
                  onClick={() => copyToClipboard("npm run build", "build")}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {copiedCommand === "build" ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-white mb-2">Pour démarrer en production :</h4>
              <div className="bg-slate-900 rounded-lg p-3 flex justify-between items-center">
                <code className="text-green-400">npm start</code>
                <Button
                  size="sm"
                  onClick={() => copyToClipboard("npm start", "start")}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {copiedCommand === "start" ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
