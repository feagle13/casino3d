"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface SlotMachineProps {
  credits: number
  setCredits: (credits: number) => void
  playerRank?: string
  onGameEnd?: (won: boolean, lpChange: number) => void
}

export default function SlotMachine({ credits, setCredits, playerRank, onGameEnd }: SlotMachineProps) {
  const [reels, setReels] = useState(["🍒", "🍒", "🍒"])
  const [spinning, setSpinning] = useState(false)
  const [bet, setBet] = useState(10)
  const [message, setMessage] = useState("Bonne chance!")
  const [lastWin, setLastWin] = useState(0)

  const symbols = ["🍒", "🍋", "🍊", "🍇", "⭐", "💎", "7️⃣", "🔔"]
  const payouts = {
    "💎💎💎": 1000,
    "7️⃣7️⃣7️⃣": 500,
    "⭐⭐⭐": 250,
    "🔔🔔🔔": 100,
    "🍇🍇🍇": 50,
    "🍊🍊🍊": 30,
    "🍋🍋🍋": 20,
    "🍒🍒🍒": 10,
    "💎💎": 50,
    "7️⃣7️⃣": 25,
    "⭐⭐": 15,
    "🍒🍒": 5,
  }

  const spin = () => {
    if (bet > credits) {
      setMessage("Mise trop élevée!")
      return
    }

    setSpinning(true)
    setCredits(credits - bet)
    setMessage("Les rouleaux tournent...")
    setLastWin(0)

    // Animation de rotation
    const spinInterval = setInterval(() => {
      setReels([
        symbols[Math.floor(Math.random() * symbols.length)],
        symbols[Math.floor(Math.random() * symbols.length)],
      ])
    }, 100)

    setTimeout(() => {
      clearInterval(spinInterval)

      // Résultat final (pur hasard)
      const finalReels = [
        symbols[Math.floor(Math.random() * symbols.length)],
        symbols[Math.floor(Math.random() * symbols.length)],
        symbols[Math.floor(Math.random() * symbols.length)],
      ]

      setReels(finalReels)
      setSpinning(false)

      // Vérifier les gains
      const combination = finalReels.join("")
      const twoSymbol = finalReels[0] + finalReels[1]

      let winAmount = 0

      if (payouts[combination as keyof typeof payouts]) {
        winAmount = (payouts[combination as keyof typeof payouts] * bet) / 10
      } else if (payouts[twoSymbol as keyof typeof payouts]) {
        winAmount = (payouts[twoSymbol as keyof typeof payouts] * bet) / 10
      }

      if (winAmount > 0) {
        setCredits((prev) => prev + winAmount)
        setLastWin(winAmount)
        setMessage(`🎉 Vous gagnez ${winAmount} crédits!`)
        if (onGameEnd) onGameEnd(true, 10)
      } else {
        setMessage("Pas de gain cette fois. Réessayez!")
        if (onGameEnd) onGameEnd(false, -5)
      }
    }, 2000)
  }

  return (
    <div className="text-white space-y-6">
      {/* Game Info */}
      <div className="flex justify-between items-center">
        <div className="flex space-x-4">
          <Badge variant="outline" className="border-yellow-400 text-yellow-400">
            Crédits: {credits}
          </Badge>
          <Badge variant="outline" className="border-purple-400 text-purple-400">
            Mise: {bet}
          </Badge>
          {lastWin > 0 && <Badge className="bg-green-600">Dernier gain: {lastWin}</Badge>}
        </div>
        <div className="text-xl font-bold">{message}</div>
      </div>

      {/* Slot Machine Display */}
      <div className="flex justify-center">
        <div className="bg-gradient-to-b from-yellow-400 to-yellow-600 p-8 rounded-lg border-4 border-yellow-300 shadow-2xl">
          <div className="bg-black p-6 rounded-lg">
            <div className="flex space-x-4 justify-center">
              {reels.map((symbol, index) => (
                <div
                  key={index}
                  className={`w-24 h-24 bg-white rounded-lg flex items-center justify-center text-5xl border-2 border-gray-300 shadow-inner ${
                    spinning ? "animate-pulse" : ""
                  }`}
                >
                  {symbol}
                </div>
              ))}
            </div>
          </div>

          {/* Machine Details */}
          <div className="mt-4 text-center">
            <div className="text-black font-bold text-lg">🎰 SUPER SLOTS 🎰</div>
            <div className="text-black text-sm">Jeu de hasard pur</div>
          </div>
        </div>
      </div>

      {/* Bet Selection */}
      <div className="space-y-4">
        <div className="flex items-center justify-center space-x-4">
          <span>Mise:</span>
          <div className="flex space-x-2">
            {[5, 10, 25, 50, 100].map((amount) => (
              <Button
                key={amount}
                variant={bet === amount ? "default" : "outline"}
                size="sm"
                onClick={() => setBet(amount)}
                disabled={amount > credits || spinning}
                className={bet === amount ? "bg-purple-600 hover:bg-purple-700" : ""}
              >
                {amount}
              </Button>
            ))}
          </div>
        </div>

        <div className="flex justify-center">
          <Button
            onClick={spin}
            disabled={spinning || bet > credits}
            className="bg-red-600 hover:bg-red-700 text-2xl px-12 py-6 shadow-lg"
          >
            {spinning ? "SPINNING..." : "🎰 SPIN! 🎰"}
          </Button>
        </div>
      </div>

      {/* Paytable */}
      <div className="space-y-2">
        <h3 className="text-lg font-bold text-center">Table des gains (pour mise de 10)</h3>
        <div className="grid grid-cols-2 gap-2 text-sm max-h-40 overflow-y-auto">
          {Object.entries(payouts).map(([combo, payout]) => (
            <div key={combo} className="flex justify-between bg-slate-800 p-2 rounded">
              <span>{combo}</span>
              <span className="text-yellow-400">{payout}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Pure Chance Notice */}
      <div className="bg-blue-900/20 rounded-xl p-4 border border-blue-500/30">
        <div className="text-center text-sm text-blue-300">
          <p>
            🎲 <strong>Jeu de hasard pur</strong> - Aucune IA impliquée
          </p>
          <p>Chaque spin est complètement aléatoire!</p>
        </div>
      </div>
    </div>
  )
}
