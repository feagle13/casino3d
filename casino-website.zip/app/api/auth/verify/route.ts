import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const token = searchParams.get("token")

  if (!token) {
    return NextResponse.redirect(new URL("/auth/error?error=InvalidToken", request.url))
  }

  try {
    // Vérifier le token
    const verificationToken = await prisma.verificationToken.findUnique({
      where: { token },
    })

    if (!verificationToken || verificationToken.expires < new Date()) {
      return NextResponse.redirect(new URL("/auth/error?error=ExpiredToken", request.url))
    }

    // Activer le compte
    await prisma.user.update({
      where: { email: verificationToken.identifier },
      data: { emailVerified: new Date() },
    })

    // Supprimer le token
    await prisma.verificationToken.delete({
      where: { token },
    })

    // Log de sécurité
    await prisma.securityLog.create({
      data: {
        action: "EMAIL_VERIFIED",
        ip: request.ip || request.headers.get("x-forwarded-for"),
        details: { email: verificationToken.identifier },
      },
    })

    return NextResponse.redirect(new URL("/auth/signin?verified=true", request.url))
  } catch (error) {
    console.error("Verification error:", error)
    return NextResponse.redirect(new URL("/auth/error?error=VerificationFailed", request.url))
  }
}
